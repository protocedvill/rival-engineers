local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 4,["6"] = 5,["7"] = 5,["8"] = 6,["9"] = 6,["11"] = 7,["12"] = 4,["13"] = 10,["14"] = 12,["15"] = 13,["16"] = 13,["17"] = 12,["18"] = 16,["19"] = 17,["20"] = 16,["21"] = 20,["22"] = 21,["23"] = 22,["24"] = 20,["25"] = 25,["26"] = 26,["27"] = 25});
local ____exports = {}
local function parseAutoStartConfig()
    local ____opt_0 = settings.startup["factorio-test-auto-start-config"]
    local json = ____opt_0 and ____opt_0.value
    if not json or json == "{}" then
        return {}
    end
    return helpers.json_to_table(json)
end
local cachedConfig
function ____exports.getAutoStartConfig()
    cachedConfig = cachedConfig or parseAutoStartConfig()
    return cachedConfig
end
function ____exports.isHeadlessMode()
    return ____exports.getAutoStartConfig().headless == true
end
function ____exports.isAutoStartEnabled()
    local config = ____exports.getAutoStartConfig()
    return config.mod ~= nil and config.mod ~= ""
end
function ____exports.getAutoStartMod()
    return ____exports.getAutoStartConfig().mod
end
return ____exports
