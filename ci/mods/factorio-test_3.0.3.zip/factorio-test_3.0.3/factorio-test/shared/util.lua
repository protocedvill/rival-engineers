local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 3,["6"] = 4,["7"] = 3,["8"] = 7,["9"] = 9,["10"] = 10,["11"] = 9});
local ____exports = {}
function ____exports.getPlayer()
    return game.players[1] or error("No player found")
end
____exports.debugAdapterEnabled = script.active_mods.debugadapter ~= nil
function ____exports.assertNever(value)
    return error(("value " .. tostring(value)) .. " should be never")
end
return ____exports
