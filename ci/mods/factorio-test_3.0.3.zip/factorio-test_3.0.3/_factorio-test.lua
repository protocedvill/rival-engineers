--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]

local ____modules = {}
local ____moduleCache = {}
local ____originalRequire = require
local function require(file, ...)
    if ____moduleCache[file] then
        return ____moduleCache[file].value
    end
    if ____modules[file] then
        local module = ____modules[file]
        local value = nil
        if (select("#", ...) > 0) then value = module(...) else value = module(file) end
        ____moduleCache[file] = { value = value }
        return value
    else
        if ____originalRequire then
            return ____originalRequire(file)
        else
            error("module '" .. file .. "' not found")
        end
    end
end
____modules = {
["lualib_bundle"] = function(...) 
local function __TS__ArrayFilter(self, callbackfn, thisArg)
    local result = {}
    local len = 0
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            len = len + 1
            result[len] = self[i]
        end
    end
    return result
end

local function __TS__ArrayMap(self, callbackfn, thisArg)
    local result = {}
    for i = 1, #self do
        result[i] = callbackfn(thisArg, self[i], i - 1, self)
    end
    return result
end

local function __TS__CountVarargs(...)
    return select("#", ...)
end

local function __TS__SparseArrayNew(...)
    local sparseArray = {...}
    sparseArray.sparseLength = __TS__CountVarargs(...)
    return sparseArray
end

local function __TS__SparseArrayPush(sparseArray, ...)
    local args = {...}
    local argsLen = __TS__CountVarargs(...)
    local listLen = sparseArray.sparseLength
    for i = 1, argsLen do
        sparseArray[listLen + i] = args[i]
    end
    sparseArray.sparseLength = listLen + argsLen
end

local function __TS__SparseArraySpread(sparseArray)
    local _unpack = unpack or table.unpack
    return _unpack(sparseArray, 1, sparseArray.sparseLength)
end

local function __TS__ObjectAssign(target, ...)
    local sources = {...}
    for i = 1, #sources do
        local source = sources[i]
        for key in pairs(source) do
            target[key] = source[key]
        end
    end
    return target
end

local __TS__StringSplit
do
    local sub = string.sub
    local find = string.find
    function __TS__StringSplit(source, separator, limit)
        if limit == nil then
            limit = 4294967295
        end
        if limit == 0 then
            return {}
        end
        local result = {}
        local resultIndex = 1
        if separator == nil or separator == "" then
            for i = 1, #source do
                result[resultIndex] = sub(source, i, i)
                resultIndex = resultIndex + 1
            end
        else
            local currentPos = 1
            while resultIndex <= limit do
                local startPos, endPos = find(source, separator, currentPos, true)
                if not startPos then
                    break
                end
                result[resultIndex] = sub(source, currentPos, startPos - 1)
                resultIndex = resultIndex + 1
                currentPos = endPos + 1
            end
            if resultIndex <= limit then
                result[resultIndex] = sub(source, currentPos)
            end
        end
        return result
    end
end

local function __TS__ArrayReduce(self, callbackFn, ...)
    local len = #self
    local k = 0
    local accumulator = nil
    if __TS__CountVarargs(...) ~= 0 then
        accumulator = ...
    elseif len > 0 then
        accumulator = self[1]
        k = 1
    else
        error("Reduce of empty array with no initial value", 0)
    end
    for i = k + 1, len do
        accumulator = callbackFn(
            nil,
            accumulator,
            self[i],
            i - 1,
            self
        )
    end
    return accumulator
end

local function __TS__StringIncludes(self, searchString, position)
    if not position then
        position = 1
    else
        position = position + 1
    end
    local index = string.find(self, searchString, position, true)
    return index ~= nil
end

local function __TS__ArrayIsArray(value)
    return type(value) == "table" and (value[1] ~= nil or next(value) == nil)
end

local function __TS__ArrayEvery(self, callbackfn, thisArg)
    for i = 1, #self do
        if not callbackfn(thisArg, self[i], i - 1, self) then
            return false
        end
    end
    return true
end

local function __TS__ArrayJoin(self, separator)
    if separator == nil then
        separator = ","
    end
    local parts = {}
    for i = 1, #self do
        parts[i] = tostring(self[i])
    end
    return table.concat(parts, separator)
end

local function __TS__StringStartsWith(self, searchString, position)
    if position == nil or position < 0 then
        position = 0
    end
    return string.sub(self, position + 1, #searchString + position) == searchString
end

local function __TS__StringEndsWith(self, searchString, endPosition)
    if endPosition == nil or endPosition > #self then
        endPosition = #self
    end
    return string.sub(self, endPosition - #searchString + 1, endPosition) == searchString
end

local function __TS__ArraySome(self, callbackfn, thisArg)
    for i = 1, #self do
        if callbackfn(thisArg, self[i], i - 1, self) then
            return true
        end
    end
    return false
end

local function __TS__Class(self)
    local c = {prototype = {}}
    c.prototype.__index = c.prototype
    c.prototype.constructor = c
    return c
end

local function __TS__ArraySetLength(self, length)
    if length < 0 or length ~= length or length == math.huge or math.floor(length) ~= length then
        error(
            "invalid array length: " .. tostring(length),
            0
        )
    end
    for i = length + 1, #self do
        self[i] = nil
    end
    return length
end

local function __TS__ArrayPushArray(self, items)
    local len = #self
    for i = 1, #items do
        len = len + 1
        self[len] = items[i]
    end
    return len
end

local function __TS__ObjectKeys(obj)
    local result = {}
    local len = 0
    for key in pairs(obj) do
        len = len + 1
        result[len] = key
    end
    return result
end

local function __TS__New(target, ...)
    local instance = setmetatable({}, target.prototype)
    instance:____constructor(...)
    return instance
end

local function __TS__ArrayPush(self, ...)
    local items = {...}
    local len = #self
    for i = 1, #items do
        len = len + 1
        self[len] = items[i]
    end
    return len
end

return {
  __TS__ArrayFilter = __TS__ArrayFilter,
  __TS__ArrayMap = __TS__ArrayMap,
  __TS__SparseArrayNew = __TS__SparseArrayNew,
  __TS__SparseArrayPush = __TS__SparseArrayPush,
  __TS__SparseArraySpread = __TS__SparseArraySpread,
  __TS__ObjectAssign = __TS__ObjectAssign,
  __TS__StringSplit = __TS__StringSplit,
  __TS__ArrayReduce = __TS__ArrayReduce,
  __TS__StringIncludes = __TS__StringIncludes,
  __TS__ArrayIsArray = __TS__ArrayIsArray,
  __TS__ArrayEvery = __TS__ArrayEvery,
  __TS__ArrayJoin = __TS__ArrayJoin,
  __TS__StringStartsWith = __TS__StringStartsWith,
  __TS__StringEndsWith = __TS__StringEndsWith,
  __TS__ArraySome = __TS__ArraySome,
  __TS__Class = __TS__Class,
  __TS__ArraySetLength = __TS__ArraySetLength,
  __TS__ArrayPushArray = __TS__ArrayPushArray,
  __TS__ObjectKeys = __TS__ObjectKeys,
  __TS__New = __TS__New,
  __TS__ArrayPush = __TS__ArrayPush
}
 end,
["results"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
function ____exports.createRunReport()
    return {results = {
        failed = 0,
        passed = 0,
        ran = 0,
        skipped = 0,
        todo = 0,
        describeBlockErrors = 0
    }, failedTestPaths = {}, reloaded = false, bailedOut = false}
end
function ____exports.recordEvent(report, event)
    local ____report_0 = report
    local results = ____report_0.results
    repeat
        local ____switch4 = event.type
        local ____cond4 = ____switch4 == "testPassed"
        if ____cond4 then
            results.ran = results.ran + 1
            results.passed = results.passed + 1
            break
        end
        ____cond4 = ____cond4 or ____switch4 == "testFailed"
        if ____cond4 then
            results.ran = results.ran + 1
            results.failed = results.failed + 1
            report.failedTestPaths[event.test.path] = true
            break
        end
        ____cond4 = ____cond4 or (____switch4 == "testSkipped" or ____switch4 == "testSkippedByUser")
        if ____cond4 then
            results.skipped = results.skipped + 1
            break
        end
        ____cond4 = ____cond4 or ____switch4 == "testTodo"
        if ____cond4 then
            results.todo = results.todo + 1
            break
        end
        ____cond4 = ____cond4 or ____switch4 == "describeBlockFailed"
        if ____cond4 then
            results.describeBlockErrors = results.describeBlockErrors + #event.block.errors
            break
        end
        ____cond4 = ____cond4 or ____switch4 == "testRunFinished"
        if ____cond4 then
            if results.failed ~= 0 or results.describeBlockErrors ~= 0 then
                results.status = "failed"
            elseif results.todo ~= 0 then
                results.status = "todo"
            else
                results.status = "passed"
            end
            break
        end
        ____cond4 = ____cond4 or ____switch4 == "testRunCancelled"
        if ____cond4 then
            results.status = "cancelled"
            break
        end
    until true
end
return ____exports
 end,
["shared.util"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
function ____exports.getPlayer()
    return game.players[1] or error("No player found")
end
____exports.debugAdapterEnabled = script.active_mods.debugadapter ~= nil
function ____exports.assertNever(value)
    return error(("value " .. tostring(value)) .. " should be never")
end
return ____exports
 end,
["tests"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local ____exports = {}
local testMatchesTagList, testMatchesPattern, countActiveTestsIn
local ____util = require("shared.util")
local assertNever = ____util.assertNever
function testMatchesTagList(test, config)
    if config.tag_whitelist then
        for ____, tag in ipairs(config.tag_whitelist) do
            if not (test.tags[tag] ~= nil) then
                return false
            end
        end
    end
    if config.tag_blacklist then
        for ____, tag in ipairs(config.tag_blacklist) do
            if test.tags[tag] ~= nil then
                return false
            end
        end
    end
    return true
end
function testMatchesPattern(test, config)
    local pattern = config.test_pattern
    if pattern == nil then
        return true
    end
    local patterns = type(pattern) == "string" and ({pattern}) or pattern
    for ____, p in ipairs(patterns) do
        if (string.match(test.path, p)) ~= nil then
            return true
        end
    end
    return false
end
function ____exports.isSkippedTest(test, state)
    return test.mode == "skip" or test.mode == "todo" or state.suite.hasFocusedTests and test.mode ~= "only" or state.isRerun and test.tags.no_rerun ~= nil or not testMatchesPattern(test, state.config) or not testMatchesTagList(test, state.config)
end
function countActiveTestsIn(block, state)
    if block.mode == "skip" then
        return 0
    end
    local result = 0
    for ____, child in ipairs(block.children) do
        if child.type == "describeBlock" then
            result = result + countActiveTestsIn(child, state)
        elseif child.type == "test" then
            if not ____exports.isSkippedTest(child, state) then
                result = result + 1
            end
        else
            assertNever(child)
        end
    end
    return result
end
function ____exports.formatSource(source)
    if not source.file then
        return "<unknown source>"
    end
    return (source.file .. ":") .. tostring(source.line or 1)
end
local function tryUseSourcemap(rawFile, line)
    if not rawFile or not line or not __TS__sourcemap then
        return nil
    end
    local fileName = string.match(rawFile, "@?(%S+)%.lua")
    if not fileName then
        return nil
    end
    local fileSourceMap = __TS__sourcemap[fileName .. ".lua"]
    if not fileSourceMap then
        return nil
    end
    local data = fileSourceMap[tostring(line)]
    if not data then
        return nil
    end
    return type(data) == "number" and ({file = fileName .. ".ts", line = data}) or data
end
function ____exports.createSource(file, line)
    return tryUseSourcemap(file, line) or ({file = file, line = line})
end
function ____exports.stepLabel(____bindingPattern0)
    local index
    local caption
    caption = ____bindingPattern0.caption
    index = ____bindingPattern0.index
    return caption or "step " .. tostring(index)
end
function ____exports.formatStepError(____bindingPattern0, message)
    local index
    local caption
    caption = ____bindingPattern0.caption
    index = ____bindingPattern0.index
    return caption ~= nil and (("In step \"" .. caption) .. "\": ") .. message or (("In step " .. tostring(index)) .. ": ") .. message
end
local function childPath(parent, name)
    return parent.path ~= "" and (parent.path .. " > ") .. name or name
end
local function warnOnDuplicatePath(parent, kind, name, path, source)
    for ____, sibling in ipairs(parent.children) do
        if sibling.path == path then
            log(((((((((("Warning: Duplicate " .. kind) .. " name \"") .. name) .. "\" in \"") .. parent.path) .. "\" at ") .. ____exports.formatSource(source)) .. " (first at ") .. ____exports.formatSource(sibling.source)) .. ")")
        end
    end
end
function ____exports.addTest(parent, name, source, func, declaredMode, tags)
    local path = childPath(parent, name)
    warnOnDuplicatePath(
        parent,
        "test",
        name,
        path,
        source
    )
    local test = {
        type = "test",
        name = name,
        path = path,
        tags = tags,
        parent = parent,
        source = source,
        indexInParent = #parent.children,
        parts = {{func = func, source = source}},
        errors = {},
        declaredMode = declaredMode,
        mode = declaredMode,
        ticksBefore = parent.ticksBetweenTests
    }
    local ____parent_children_0 = parent.children
    ____parent_children_0[#____parent_children_0 + 1] = test
    return test
end
function ____exports.addDescribeBlock(parent, name, source, declaredMode, tags)
    local path = childPath(parent, name)
    warnOnDuplicatePath(
        parent,
        "describe",
        name,
        path,
        source
    )
    local block = {
        type = "describeBlock",
        name = name,
        path = path,
        tags = tags,
        parent = parent,
        indexInParent = #parent.children,
        source = source,
        hooks = {},
        children = {},
        declaredMode = declaredMode,
        ticksBetweenTests = parent.ticksBetweenTests,
        errors = {}
    }
    local ____parent_children_1 = parent.children
    ____parent_children_1[#____parent_children_1 + 1] = block
    return block
end
function ____exports.createRootDescribeBlock(config)
    return {
        type = "describeBlock",
        name = "",
        path = "",
        tags = {},
        source = {},
        parent = nil,
        children = {},
        indexInParent = -1,
        hooks = {},
        declaredMode = nil,
        mode = nil,
        ticksBetweenTests = config.default_ticks_between_tests,
        errors = {}
    }
end
function ____exports.countActiveTests(state)
    return countActiveTestsIn(state.suite.rootBlock, state)
end
local function hooksOfType(block, ____type)
    return __TS__ArrayMap(
        __TS__ArrayFilter(
            block.hooks,
            function(____, hook) return hook.type == ____type end
        ),
        function(____, hook) return hook.func end
    )
end
function ____exports.collectBeforeEachHooks(block)
    local parentHooks = block.parent and ____exports.collectBeforeEachHooks(block.parent) or ({})
    local ____array_2 = __TS__SparseArrayNew(table.unpack(parentHooks))
    __TS__SparseArrayPush(
        ____array_2,
        table.unpack(hooksOfType(block, "beforeEach"))
    )
    return {__TS__SparseArraySpread(____array_2)}
end
function ____exports.collectAfterEachHooks(block)
    local parentHooks = block.parent and ____exports.collectAfterEachHooks(block.parent) or ({})
    local ____array_3 = __TS__SparseArrayNew(table.unpack(hooksOfType(block, "afterEach")))
    __TS__SparseArrayPush(
        ____array_3,
        table.unpack(parentHooks)
    )
    return {__TS__SparseArraySpread(____array_3)}
end
return ____exports
 end,
["test-events"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
return ____exports
 end,
["shared.auto-start-config"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local function parseAutoStartConfig()
    local ____opt_0 = settings.startup["factorio-test-auto-start-config"]
    local json = ____opt_0 and ____opt_0.value
    if not json or json == "{}" then
        return {}
    end
    return helpers.json_to_table(json)
end
local cachedConfig
function ____exports.getAutoStartConfig()
    cachedConfig = cachedConfig or parseAutoStartConfig()
    return cachedConfig
end
function ____exports.isHeadlessMode()
    return ____exports.getAutoStartConfig().headless == true
end
function ____exports.isAutoStartEnabled()
    local config = ____exports.getAutoStartConfig()
    return config.mod ~= nil and config.mod ~= ""
end
function ____exports.getAutoStartMod()
    return ____exports.getAutoStartConfig().mod
end
return ____exports
 end,
["builtin-test-event-listeners"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____auto_2Dstart_2Dconfig = require("shared.auto-start-config")
local isHeadlessMode = ____auto_2Dstart_2Dconfig.isHeadlessMode
local function emitResult(status)
    print("FACTORIO-TEST-RESULT:" .. status)
    if isHeadlessMode() then
        error("Factorio Test: intentionally erroring to exit the process")
    end
end
____exports.gameEnvironmentListener = function(event, state)
    repeat
        local ____switch5 = event.type
        local ____cond5 = ____switch5 == "testRunStarted"
        if ____cond5 then
            game.speed = state.config.game_speed
            game.autosave_enabled = false
            local ____this_1
            ____this_1 = state.config
            local ____opt_0 = ____this_1.before_test_run
            if ____opt_0 ~= nil then
                ____opt_0(____this_1)
            end
            break
        end
        ____cond5 = ____cond5 or ____switch5 == "testRunFinished"
        if ____cond5 then
            do
                game.speed = 1
                if state.config.sound_effects then
                    local passed = state.report.results.status == "passed" or state.report.results.status == "todo"
                    game.play_sound({path = passed and "utility/game_won" or "utility/game_lost"})
                end
                break
            end
        end
        ____cond5 = ____cond5 or ____switch5 == "testRunCancelled"
        if ____cond5 then
            game.speed = 1
            if state.config.sound_effects then
                game.play_sound({path = "utility/console_message"})
            end
            break
        end
        ____cond5 = ____cond5 or ____switch5 == "loadError"
        if ____cond5 then
            game.speed = 1
            game.play_sound({path = "utility/console_message"})
            break
        end
        ____cond5 = ____cond5 or ____switch5 == "stepPaused"
        if ____cond5 then
            game.tick_paused = true
            game.speed = 1
            break
        end
        ____cond5 = ____cond5 or ____switch5 == "stepResumed"
        if ____cond5 then
            game.tick_paused = false
            game.speed = state.config.game_speed
            break
        end
    until true
end
local function endRun(state, status)
    local ____this_3
    ____this_3 = state.config
    local ____opt_2 = ____this_3.after_test_run
    if ____opt_2 ~= nil then
        ____opt_2(____this_3)
    end
    emitResult(status)
end
--- emitResult aborts the process in headless mode, so nothing after this runs there.
____exports.resultListener = function(event, state)
    repeat
        local ____switch11 = event.type
        local ____cond11 = ____switch11 == "testRunFinished"
        if ____cond11 then
            do
                local bailedPrefix = state.report.bailedOut and "bailed:" or ""
                local focusedSuffix = state.suite.hasFocusedTests and ":focused" or ""
                endRun(state, (bailedPrefix .. state.report.results.status) .. focusedSuffix)
                break
            end
        end
        ____cond11 = ____cond11 or ____switch11 == "testRunCancelled"
        if ____cond11 then
            endRun(state, state.report.bailedOut and "bailed" or "cancelled")
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "loadError"
        if ____cond11 then
            emitResult("loadError")
            break
        end
    until true
end
return ____exports
 end,
["cli-events"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local ____tests = require("tests")
local countActiveTests = ____tests.countActiveTests
local function emitEvent(event)
    print("FACTORIO-TEST-EVENT:" .. helpers.table_to_json(event))
end
local function sourceToLocation(source)
    if not source.file then
        return nil
    end
    local result = {file = source.file}
    if source.line ~= nil then
        result.line = source.line
    end
    return result
end
local function testToInfo(test)
    local result = {path = test.path}
    local source = sourceToLocation(test.source)
    if source then
        result.source = source
    end
    return result
end
local function blockToInfo(block)
    local result = {path = block.path}
    local source = sourceToLocation(block.source)
    if source then
        result.source = source
    end
    return result
end
____exports.cliEventEmitter = function(event, state)
    repeat
        local ____switch11 = event.type
        local ____cond11 = ____switch11 == "testRunStarted"
        if ____cond11 then
            emitEvent({
                type = "testRunStarted",
                total = countActiveTests(state)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testStarted"
        if ____cond11 then
            emitEvent({
                type = "testStarted",
                test = testToInfo(event.test)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "stepStarted"
        if ____cond11 then
            emitEvent({
                type = "stepStarted",
                test = testToInfo(event.test),
                step = event.step
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testPassed"
        if ____cond11 then
            emitEvent({
                type = "testPassed",
                test = testToInfo(event.test)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testFailed"
        if ____cond11 then
            emitEvent({
                type = "testFailed",
                test = testToInfo(event.test),
                errors = {table.unpack(event.test.errors)}
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testSkipped"
        if ____cond11 then
            emitEvent({
                type = "testSkipped",
                test = testToInfo(event.test)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testTodo"
        if ____cond11 then
            emitEvent({
                type = "testTodo",
                test = testToInfo(event.test)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "describeBlockEntered"
        if ____cond11 then
            emitEvent({
                type = "describeBlockEntered",
                block = blockToInfo(event.block)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "describeBlockFinished"
        if ____cond11 then
            emitEvent({
                type = "describeBlockFinished",
                block = blockToInfo(event.block)
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "describeBlockFailed"
        if ____cond11 then
            emitEvent({
                type = "describeBlockFailed",
                block = blockToInfo(event.block),
                errors = {table.unpack(event.block.errors)}
            })
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testRunFinished"
        if ____cond11 then
            emitEvent({type = "testRunFinished", results = state.report.results})
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "testRunCancelled"
        if ____cond11 then
            emitEvent({type = "testRunCancelled"})
            break
        end
        ____cond11 = ____cond11 or ____switch11 == "loadError"
        if ____cond11 then
            emitEvent({type = "loadError", error = state.suite.rootBlock.errors[1] or "Unknown error"})
            break
        end
    until true
end
return ____exports
 end,
["config"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local ____exports = {}
local function getSettingsConfig()
    local ____opt_0 = settings.global["factorio-test-config"]
    local json = ____opt_0 and ____opt_0.value
    if not json or json == "{}" then
        return {}
    end
    return helpers.json_to_table(json)
end
local defaultConfig = {
    default_timeout = 60 * 60,
    default_ticks_between_tests = 1,
    game_speed = 1000,
    log_passed_tests = true,
    log_skipped_tests = false,
    sound_effects = false,
    reorder_failed_first = false,
    load_luassert = false,
    step = false
}
function ____exports.withDefaultConfig(config)
    return __TS__ObjectAssign({}, defaultConfig, config)
end
function ____exports.disableStepIfHeadless(config, headless)
    if not headless or not config.step then
        return {config = config}
    end
    return {
        config = __TS__ObjectAssign({}, config, {step = false}),
        warning = "factorio-test: step requires graphics mode (there is no GUI to continue from); ignoring it"
    }
end
--- Settings (set by the CLI) override the config the mod under test passed in.
function ____exports.resolveConfig(modConfig)
    return ____exports.withDefaultConfig(__TS__ObjectAssign(
        {},
        modConfig,
        getSettingsConfig()
    ))
end
return ____exports
 end,
["each-format"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayIsArray = ____lualib.__TS__ArrayIsArray
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local ____exports = {}
local function getNestedProperty(obj, path)
    return __TS__ArrayReduce(
        __TS__StringSplit(path, "."),
        function(____, current, key)
            if current ~= nil and type(current) == "table" then
                return current[key]
            end
            return nil
        end,
        obj
    )
end
local function formatValue(value)
    if value == nil then
        return tostring(value)
    end
    if type(value) == "table" then
        return serpent.line(value)
    end
    return tostring(value)
end
function ____exports.formatTestName(template, row, index)
    local result = template
    result = (string.gsub(
        result,
        "%%#",
        tostring(index)
    ))
    result = (string.gsub(
        result,
        "%%%$",
        tostring(index + 1)
    ))
    if #row == 1 and type(row[1]) == "table" and row[1] ~= nil then
        local obj = row[1]
        result = (string.gsub(
            result,
            "%$([%w_][%w_%.]*)",
            function(path)
                local ____path_includes_result_0
                if __TS__StringIncludes(path, ".") then
                    ____path_includes_result_0 = getNestedProperty(obj, path)
                else
                    ____path_includes_result_0 = obj[path]
                end
                local value = ____path_includes_result_0
                return formatValue(value)
            end
        ))
    end
    local valueIndex = 0
    result = (string.gsub(
        result,
        "%%p",
        function()
            local ____row_2 = row
            local ____valueIndex_1 = valueIndex
            valueIndex = ____valueIndex_1 + 1
            local value = ____row_2[____valueIndex_1 + 1]
            local ____temp_4
            if type(value) == "table" and value ~= nil then
                ____temp_4 = serpent.block(value)
            else
                local ____value_3 = value
                if ____value_3 == nil then
                    ____value_3 = "nil"
                end
                ____temp_4 = tostring(____value_3)
            end
            return ____temp_4
        end
    ))
    if (string.match(result, "%%[disfoxXeEgGc]")) then
        local rowValues = __TS__ArrayMap(
            row,
            function(____, v) return type(v) == "table" and serpent.line(v) or v end
        )
        result = string.format(
            result,
            table.unpack(rowValues)
        )
    end
    return result
end
function ____exports.createEachItems(values, name)
    if #values == 0 then
        error(".each called with no data")
    end
    local valuesAsRows = __TS__ArrayEvery(
        values,
        function(____, v) return __TS__ArrayIsArray(v) end
    ) and values or __TS__ArrayMap(
        values,
        function(____, v) return {v} end
    )
    return __TS__ArrayMap(
        valuesAsRows,
        function(____, row, index) return {
            name = ____exports.formatTestName(name, row, index),
            row = row
        } end
    )
end
return ____exports
 end,
["output"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayJoin = ____lualib.__TS__ArrayJoin
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local ____exports = {}
local ____util = require("shared.util")
local debugAdapterEnabled = ____util.debugAdapterEnabled
local Colors = {
    [1] = {1, 1, 1},
    [2] = {71, 221, 37},
    [3] = {252, 237, 50},
    [4] = {230, 60, 60},
    [5] = {177, 156, 220}
}
local ColorFormat = {}
for code, color in pairs(Colors) do
    ColorFormat[code] = ("[color=" .. __TS__ArrayJoin(color)) .. "]"
end
local function red(text)
    return {text = text, color = 4}
end
local function yellow(text)
    return {text = text, color = 3}
end
local function green(text)
    return {text = text, color = 2}
end
local function purple(text)
    return {text = text, color = 5}
end
local function formatError(text)
    local withSpaces = (string.gsub(text, "\t", "    "))
    local withIndent = (string.gsub(withSpaces, "\n", "\n    "))
    return {richText = "    " .. withIndent, plainText = text, firstColor = 4}
end
local function m(strings, ...)
    local substitutions = {...}
    local plainResult = {}
    local richResult = {""}
    local firstColor = nil
    local isString = true
    for i = 1, #strings * 2 - 1 do
        do
            local ____temp_0
            if i % 2 == 0 then
                ____temp_0 = strings[i / 2 + 1]
            else
                ____temp_0 = substitutions[(i - 1) / 2 + 1]
            end
            local element = ____temp_0
            if element == nil then
                goto __continue9
            end
            local color
            local part
            if type(element) == "table" then
                if element.object_name ~= nil then
                    part = element
                else
                    part = element.text
                    color = element.color
                    if firstColor == nil then
                        firstColor = color
                    end
                end
            else
                part = element
            end
            if color then
                richResult[#richResult + 1] = ColorFormat[color]
            end
            local partIsStr = type(part) == "string"
            if not partIsStr and isString then
                richResult = {
                    "",
                    table.concat(richResult)
                }
                isString = false
            end
            plainResult[#plainResult + 1] = partIsStr and part or "<Profiler>"
            richResult[#richResult + 1] = part
            if color then
                richResult[#richResult + 1] = "[/color]"
            end
        end
        ::__continue9::
    end
    return {
        richText = richResult,
        plainText = table.concat(plainResult),
        firstColor = firstColor
    }
end
local function initDebugAdapterOutput()
    if __DebugAdapter == nil then
        __DebugAdapter = {
            stepIgnore = function(f) return f end,
            stepIgnoreAll = function(f) return f end
        }
    end
    return require("__debugadapter__.print").outputEvent
end
local daOutputEvent = debugAdapterEnabled and initDebugAdapterOutput() or nil
local DebugAdapterCategories = {
    [1] = "stdout",
    [2] = "stdout",
    [3] = "console",
    [4] = "stderr",
    [5] = "console"
}
local function printDebugAdapterText(text, source, category)
    local lines = __TS__StringSplit(text, "\n")
    for ____, line in ipairs(lines) do
        local sourceFile
        local sourceLine
        if source then
            sourceFile = source.file
            sourceLine = source.line
            source = nil
        else
            local ____, ____, file1, line1 = string.find(line, "(__[%w%-_]+__/.-%.%a+):(%d*)")
            sourceFile = file1
            sourceLine = tonumber(line1)
        end
        if sourceFile and not __TS__StringStartsWith(sourceFile, "@") then
            sourceFile = "@" .. sourceFile
        end
        daOutputEvent({category = category, output = line})
        daOutputEvent({category = category, output = "\n"}, sourceFile ~= nil and ({source = sourceFile, currentline = sourceLine or 1}) or nil)
    end
end
____exports.debugAdapterLogger = function(message, source)
    local color = message.firstColor or 1
    local category = DebugAdapterCategories[color]
    printDebugAdapterText(message.plainText, source, category)
end
____exports.logLogger = function(message)
    print("FACTORIO-TEST-MESSAGE-START")
    log(message.plainText)
    print("FACTORIO-TEST-MESSAGE-END")
end
function ____exports.createLogListener(handlers)
    local function output(message, source)
        for ____, handler in ipairs(handlers) do
            handler(message, source)
        end
    end
    return function(event, state)
        repeat
            local ____switch34 = event.type
            local ____cond34 = ____switch34 == "testRunStarted"
            if ____cond34 then
                do
                    output(m({[1] = "Starting test run...", raw = {"Starting test run..."}}))
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "testPassed"
            if ____cond34 then
                do
                    if state.config.log_passed_tests then
                        local ____event_1 = event
                        local test = ____event_1.test
                        output(
                            m(
                                {
                                    [1] = "",
                                    [2] = " ",
                                    [3] = " (",
                                    [4] = "",
                                    [5] = ")",
                                    raw = {
                                        "",
                                        " ",
                                        " (",
                                        "",
                                        ")"
                                    }
                                },
                                green("PASS"),
                                test.path,
                                test.profiler,
                                (test.tags.after_reload_mods ~= nil or test.tags.after_reload_script ~= nil) and " after reload" or ""
                            ),
                            test.source
                        )
                    end
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "testFailed"
            if ____cond34 then
                do
                    local ____event_2 = event
                    local test = ____event_2.test
                    output(
                        m(
                            {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                            red("FAIL"),
                            test.path
                        ),
                        test.source
                    )
                    for ____, ____error in ipairs(test.errors) do
                        output(formatError(____error))
                    end
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "testTodo"
            if ____cond34 then
                do
                    local ____event_3 = event
                    local test = ____event_3.test
                    output(
                        m(
                            {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                            purple("TODO"),
                            test.path
                        ),
                        test.source
                    )
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "testSkipped"
            if ____cond34 then
                do
                    if state.config.log_skipped_tests then
                        local ____event_4 = event
                        local test = ____event_4.test
                        output(
                            m(
                                {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                                yellow("SKIP"),
                                test.path
                            ),
                            test.source
                        )
                    end
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "testSkippedByUser"
            if ____cond34 then
                do
                    local ____event_5 = event
                    local test = ____event_5.test
                    output(
                        m(
                            {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                            yellow("SKIP"),
                            test.path
                        ),
                        test.source
                    )
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "describeBlockFailed"
            if ____cond34 then
                do
                    local ____event_6 = event
                    local block = ____event_6.block
                    output(
                        m(
                            {[1] = "", [2] = " ", [3] = "", raw = {"", " ", ""}},
                            red("ERROR"),
                            block.path
                        ),
                        block.source
                    )
                    for ____, ____error in ipairs(block.errors) do
                        output(formatError(____error))
                    end
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "testRunFinished"
            if ____cond34 then
                do
                    local report = state.report
                    local status = report.results.status
                    output(m(
                        {[1] = "", [2] = "", raw = {"", ""}},
                        {
                            text = "Test run finished: " .. tostring(status == "todo" and "passed with todo tests" or status),
                            color = status == "passed" and 2 or (status == "failed" and 4 or (status == "todo" and 5 or 1))
                        }
                    ))
                    output(m({[1] = "", [2] = "", [3] = "", raw = {"", "", ""}}, report.profiler, report.reloaded and " since last reload" or ""))
                    break
                end
            end
            ____cond34 = ____cond34 or ____switch34 == "loadError"
            if ____cond34 then
                do
                    output(m(
                        {[1] = "", [2] = " There was an load error:", raw = {"", " There was an load error:"}},
                        red("ERROR")
                    ))
                    output(formatError(state.suite.rootBlock.errors[1]))
                    break
                end
            end
        until true
    end
end
return ____exports
 end,
["pcall-with-stacktrace"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local ____exports = {}
local getErrorWithStacktrace
function getErrorWithStacktrace(____error)
    local stacktrace = debug.traceback(
        tostring(____error),
        3
    )
    local lines = __TS__StringSplit(stacktrace, "\n")
    do
        local i = 1
        local l = #lines
        while i <= l do
            if __TS__StringEndsWith(lines[i], ": in function '__factorio_test__pcallWithStacktrace'") then
                if lines[i - 3 + 1] == "\t[C]: in function 'rawxpcall'" then
                    i = i - 1
                end
                return table.concat(lines, "\n", 1, i - 2)
            end
            i = i + 1
        end
    end
    return stacktrace
end
function ____exports.__factorio_test__pcallWithStacktrace(fn, ...)
    local success, result = xpcall(fn, getErrorWithStacktrace, ...)
    return success, result
end
return ____exports
 end,
["test-mode"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArraySome = ____lualib.__TS__ArraySome
local ____exports = {}
local applyModeToAllChildren, markChildrenWithFocus
function applyModeToAllChildren(block, mode)
    for ____, child in ipairs(block.children) do
        do
            if child.declaredMode == "skip" then
                goto __continue9
            end
            if mode == "only" and child.declaredMode ~= nil then
                child.mode = child.declaredMode
            else
                child.mode = mode
            end
            if child.type == "describeBlock" then
                applyModeToAllChildren(child, mode)
            end
        end
        ::__continue9::
    end
end
function markChildrenWithFocus(state, block)
    for ____, child in ipairs(block.children) do
        if child.declaredMode == "only" then
            state.hasFocusedTests = true
        end
    end
end
function ____exports.propagateTestMode(state, block, parentMode)
    if parentMode == "skip" then
        applyModeToAllChildren(block, "skip")
        return
    end
    if parentMode == "only" then
        state.hasFocusedTests = true
        local hasNestedOnly = __TS__ArraySome(
            block.children,
            function(____, child) return child.declaredMode == "only" end
        )
        if hasNestedOnly then
            markChildrenWithFocus(state, block)
        else
            applyModeToAllChildren(block, "only")
        end
        return
    end
    markChildrenWithFocus(state, block)
end
return ____exports
 end,
["state"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
local ____results = require("results")
local createRunReport = ____results.createRunReport
local ____test_2Dmode = require("test-mode")
local propagateTestMode = ____test_2Dmode.propagateTestMode
local ____tests = require("tests")
local createRootDescribeBlock = ____tests.createRootDescribeBlock
____exports.TestContext = __TS__Class()
local TestContext = ____exports.TestContext
TestContext.name = "TestContext"
function TestContext.prototype.____constructor(self, store)
    self.store = store
end
function TestContext.prototype.beginDefinition(self, config)
    local rootBlock = createRootDescribeBlock(config)
    self.state = {
        kind = "definition",
        config = config,
        rootBlock = rootBlock,
        currentBlock = rootBlock,
        hasFocusedTests = false
    }
end
function TestContext.prototype.definition(self)
    local state = self.state
    if (state and state.kind) == "definition" then
        return state
    end
    local testRun = state and state.currentTestRun
    if testRun then
        error(("Tests and hooks cannot be nested inside test \"" .. testRun.test.path) .. "\"")
    end
    error("Tests and hooks cannot be added/configured at this time")
end
function TestContext.prototype.endDefinition(self)
    local definition = self:definition()
    local config = definition.config
    local rootBlock = definition.rootBlock
    propagateTestMode(definition, rootBlock, nil)
    local testState = {
        kind = "test",
        config = config,
        suite = {rootBlock = rootBlock, hasFocusedTests = definition.hasFocusedTests},
        isRerun = false,
        report = createRunReport(),
        store = self.store
    }
    self.state = testState
    return testState
end
function TestContext.prototype.testState(self)
    local state = self.state
    if (state and state.kind) == "test" then
        return state
    end
    error("Tests are not configured to be run")
end
function ____exports.consumeTags(definition)
    local result = definition.currentTags
    definition.currentTags = nil
    return result or ({})
end
function ____exports.setToLoadErrorState(state, ____error)
    state.store.stage:set("LoadError")
    local rootBlock = createRootDescribeBlock(state.config)
    rootBlock.errors = {____error}
    state.suite = {rootBlock = rootBlock, hasFocusedTests = false}
    state.currentTestRun = nil
end
return ____exports
 end,
["reload-resume"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__ArrayPushArray = ____lualib.__TS__ArrayPushArray
local ____exports = {}
local ____util = require("util")
local ____table = ____util.table
local compare = ____table.compare
--- Snapshots a test, and detaches its `parts` so they are not saved into `storage`.
local function snapshotAndDetachTest(test)
    local result = {
        type = "test",
        path = test.path,
        tags = test.tags,
        source = test.source,
        numParts = #test.parts,
        mode = test.mode,
        ticksBefore = test.ticksBefore,
        errors = test.errors,
        profiler = test.profiler
    }
    test.parts = nil
    return result
end
--- Snapshots a describe block, and detaches its `hooks` so they are not saved into `storage`.
local function snapshotAndDetachDescribeBlock(block)
    local result = {
        type = "describeBlock",
        path = block.path,
        tags = block.tags,
        source = block.source,
        children = __TS__ArrayMap(
            block.children,
            function(____, child) return child.type == "test" and snapshotAndDetachTest(child) or snapshotAndDetachDescribeBlock(child) end
        ),
        hookTypes = __TS__ArrayMap(
            block.hooks,
            function(____, hook) return hook.type end
        ),
        mode = block.mode,
        ticksBetweenTests = block.ticksBetweenTests,
        errors = block.errors
    }
    block.hooks = nil
    return result
end
local function valuesMatch(a, b)
    if a == b then
        return true
    end
    return type(a) == "table" and type(b) == "table" and compare(a, b)
end
local function fieldsMatch(path, fields)
    for ____, ____value in ipairs(fields) do
        local name = ____value[1]
        local saved = ____value[2]
        local current = ____value[3]
        do
            if valuesMatch(saved, current) then
                goto __continue9
            end
            log((((((("Structure mismatch in \"" .. path) .. "\": ") .. name) .. " ") .. serpent.line(saved)) .. " !== ") .. serpent.line(current))
            return false
        end
        ::__continue9::
    end
    return true
end
local function testFieldsMatch(saved, current)
    return fieldsMatch(saved.path, {
        {"path", saved.path, current.path},
        {"tags", saved.tags, current.tags},
        {"source", saved.source, current.source},
        {"numParts", saved.numParts, #current.parts},
        {"mode", saved.mode, current.mode},
        {"ticksBefore", saved.ticksBefore, current.ticksBefore}
    })
end
local function describeBlockFieldsMatch(saved, current)
    return fieldsMatch(
        saved.path,
        {
            {"path", saved.path, current.path},
            {"tags", saved.tags, current.tags},
            {"source", saved.source, current.source},
            {
                "hookTypes",
                saved.hookTypes,
                __TS__ArrayMap(
                    current.hooks,
                    function(____, hook) return hook.type end
                )
            },
            {"mode", saved.mode, current.mode},
            {"ticksBetweenTests", saved.ticksBetweenTests, current.ticksBetweenTests},
            {"children.length", #saved.children, #current.children}
        }
    )
end
local function childrenByPath(block)
    local map = {}
    for ____, child in ipairs(block.children) do
        if map[child.path] ~= nil then
            log(("Duplicate test/describe path \"" .. child.path) .. "\" - this will cause reload issues")
        end
        map[child.path] = child
    end
    return map
end
local function describeBlockStructuresMatch(saved, current)
    if not describeBlockFieldsMatch(saved, current) then
        return false
    end
    local currentByPath = childrenByPath(current)
    return __TS__ArrayEvery(
        saved.children,
        function(____, child)
            local currentChild = currentByPath[child.path]
            if not currentChild then
                log(((("Structure mismatch in \"" .. saved.path) .. "\": child \"") .. child.path) .. "\" not found in current")
                return false
            end
            if currentChild.type ~= child.type then
                log(((((((("Structure mismatch in \"" .. saved.path) .. "\": child \"") .. child.path) .. "\" type \"") .. child.type) .. "\" !== \"") .. currentChild.type) .. "\"")
                return false
            end
            local ____temp_0
            if child.type == "test" then
                ____temp_0 = testFieldsMatch(child, currentChild)
            else
                ____temp_0 = describeBlockStructuresMatch(child, currentChild)
            end
            return ____temp_0
        end
    )
end
local function restoreTestState(saved, current)
    __TS__ArraySetLength(current.errors, 0)
    __TS__ArrayPushArray(current.errors, saved.errors)
    current.profiler = saved.profiler
end
local function restoreDescribeBlockState(saved, current)
    __TS__ArraySetLength(current.errors, 0)
    __TS__ArrayPushArray(current.errors, saved.errors)
    local currentByPath = childrenByPath(current)
    for ____, savedChild in ipairs(saved.children) do
        local currentChild = currentByPath[savedChild.path]
        if savedChild.type == "test" then
            restoreTestState(savedChild, currentChild)
        else
            restoreDescribeBlockState(savedChild, currentChild)
        end
    end
end
local function findTestByPath(block, path)
    for ____, child in ipairs(block.children) do
        if child.type == "test" then
            if child.path == path then
                return child
            end
        else
            local found = findTestByPath(child, path)
            if found then
                return found
            end
        end
    end
    return nil
end
function ____exports.prepareReload(testState, resumePoint)
    local ____resumePoint_1 = resumePoint
    local test = ____resumePoint_1.test
    local partIndex = ____resumePoint_1.partIndex
    local stepping = ____resumePoint_1.stepping
    local ____testState_2 = testState
    local store = ____testState_2.store
    store:persisted().resume = {
        rootBlock = snapshotAndDetachDescribeBlock(testState.suite.rootBlock),
        results = testState.report.results,
        failedTestPaths = testState.report.failedTestPaths,
        isRerun = testState.isRerun,
        stepping = stepping,
        resumeTestPath = test.path,
        resumePartIndex = partIndex,
        profiler = testState.report.profiler
    }
    testState.suite.rootBlock = nil
    testState.currentTestRun = nil
    store.stage:set("ReloadingMods")
end
function ____exports.resumeAfterReload(state)
    local persisted = state.store:persisted()
    local testResume = persisted.resume or error("attempting to resume after reload without resume data saved")
    persisted.resume = nil
    state.isRerun = testResume.isRerun
    state.report = {
        results = testResume.results,
        profiler = testResume.profiler,
        failedTestPaths = testResume.failedTestPaths,
        reloaded = true,
        bailedOut = false
    }
    local saved = testResume.rootBlock
    if not describeBlockStructuresMatch(saved, state.suite.rootBlock) then
        return nil
    end
    restoreDescribeBlockState(saved, state.suite.rootBlock)
    local test = findTestByPath(state.suite.rootBlock, testResume.resumeTestPath)
    if not test then
        return nil
    end
    return {test = test, partIndex = testResume.resumePartIndex, stepping = testResume.stepping}
end
return ____exports
 end,
["test-reordering"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
local markPrioritized, sortRecursive
function markPrioritized(block, failedPaths, prioritized)
    local anyFailed = false
    for ____, child in ipairs(block.children) do
        local ____temp_0
        if child.type == "test" then
            ____temp_0 = failedPaths[child.path] ~= nil
        else
            ____temp_0 = markPrioritized(child, failedPaths, prioritized)
        end
        local failed = ____temp_0
        if failed then
            prioritized[child] = true
            anyFailed = true
        end
    end
    return anyFailed
end
function sortRecursive(block, prioritized)
    table.sort(
        block.children,
        function(a, b)
            local aPriority = prioritized[a] ~= nil
            if aPriority ~= (prioritized[b] ~= nil) then
                return aPriority
            end
            return a.indexInParent < b.indexInParent
        end
    )
    for i, child in ipairs(block.children) do
        child.indexInParent = i - 1
        if child.type == "describeBlock" then
            sortRecursive(child, prioritized)
        end
    end
end
function ____exports.shouldReorderFailedFirst(config, failedPaths)
    return config.reorder_failed_first ~= false and failedPaths ~= nil and (next(failedPaths)) ~= nil
end
function ____exports.reorderFailedFirst(root, failedPaths)
    local prioritized = {}
    markPrioritized(root, failedPaths, prioritized)
    sortRecursive(root, prioritized)
end
return ____exports
 end,
["runner"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__ArraySome = ____lualib.__TS__ArraySome
local ____exports = {}
local ____pcall_2Dwith_2Dstacktrace = require("pcall-with-stacktrace")
local __factorio_test__pcallWithStacktrace = ____pcall_2Dwith_2Dstacktrace.__factorio_test__pcallWithStacktrace
local ____reload_2Dresume = require("reload-resume")
local prepareReload = ____reload_2Dresume.prepareReload
local resumeAfterReload = ____reload_2Dresume.resumeAfterReload
local ____results = require("results")
local createRunReport = ____results.createRunReport
local recordEvent = ____results.recordEvent
local ____util = require("shared.util")
local assertNever = ____util.assertNever
local ____state = require("state")
local setToLoadErrorState = ____state.setToLoadErrorState
local ____test_2Dreordering = require("test-reordering")
local reorderFailedFirst = ____test_2Dreordering.reorderFailedFirst
local shouldReorderFailedFirst = ____test_2Dreordering.shouldReorderFailedFirst
local ____tests = require("tests")
local collectAfterEachHooks = ____tests.collectAfterEachHooks
local collectBeforeEachHooks = ____tests.collectBeforeEachHooks
local formatSource = ____tests.formatSource
local formatStepError = ____tests.formatStepError
local isSkippedTest = ____tests.isSkippedTest
local stepLabel = ____tests.stepLabel
local function newPartRun(partIndex)
    return {
        partIndex = partIndex,
        async = false,
        timeout = 0,
        asyncDone = false,
        ticksElapsed = 0,
        onTickFuncs = {}
    }
end
local function stepPartLabel(test, partIndex)
    return stepLabel(test.parts[partIndex + 1].step)
end
local function stepPointTest(point)
    return point.kind == "testStart" and point.test or point.testRun.test
end
local function pushPartError(test, part, message)
    local ____test_parts_index_0 = test.parts[part.partIndex + 1]
    local step = ____test_parts_index_0.step
    local ____test_errors_1 = test.errors
    ____test_errors_1[#____test_errors_1 + 1] = step and formatStepError(step, message) or message
end
local function runBlockHooks(block, ____type, recordErrors)
    for ____, hook in ipairs(block.hooks) do
        do
            if hook.type ~= ____type then
                goto __continue7
            end
            local success, message = __factorio_test__pcallWithStacktrace(hook.func)
            if not success and recordErrors then
                local ____block_errors_2 = block.errors
                ____block_errors_2[#____block_errors_2 + 1] = (("Error running " .. ____type) .. ": ") .. tostring(message)
            end
        end
        ::__continue7::
    end
end
local function runAfterEachHooks(testRun, recordErrors)
    local ____testRun_3 = testRun
    local test = ____testRun_3.test
    local afterTestFuncs = ____testRun_3.afterTestFuncs
    local ____array_4 = __TS__SparseArrayNew(table.unpack(afterTestFuncs))
    __TS__SparseArrayPush(
        ____array_4,
        table.unpack(collectAfterEachHooks(test.parent))
    )
    local hooks = {__TS__SparseArraySpread(____array_4)}
    for ____, hook in ipairs(hooks) do
        local success, message = __factorio_test__pcallWithStacktrace(hook)
        if not success and recordErrors then
            local ____test_errors_5 = test.errors
            ____test_errors_5[#____test_errors_5 + 1] = message
        end
    end
end
local function isPartComplete(test, part)
    return #test.errors ~= 0 or not part.async or part.asyncDone or not part.explicitAsync and (next(part.onTickFuncs)) == nil
end
____exports.TestRunner = __TS__Class()
local TestRunner = ____exports.TestRunner
TestRunner.name = "TestRunner"
function TestRunner.prototype.____constructor(self, state, listeners)
    self.state = state
    self.listeners = listeners
    self.status = "notStarted"
    self.cancelRequested = false
    self.failureCount = 0
    self.stepping = false
    state.currentTestRun = nil
end
function TestRunner.prototype.emit(self, event)
    recordEvent(self.state.report, event)
    for ____, listener in ipairs(self.listeners) do
        listener(event, self.state)
    end
end
function TestRunner.prototype.tick(self)
    if self.status == "done" or self.stepPause then
        return
    end
    if self.cancelRequested then
        self:cancelRun()
        return
    end
    if self.status == "notStarted" then
        self:begin()
        return
    end
    local resumePoint = self.resumePoint
    self.resumePoint = nil
    if not resumePoint or not self:resume(resumePoint) then
        self:advance()
    end
end
function TestRunner.prototype.isDone(self)
    return self.status == "done"
end
function TestRunner.prototype.isStepPaused(self)
    return self.stepPause ~= nil
end
function TestRunner.prototype.requestCancel(self)
    self.cancelRequested = true
    if not self.stepPause then
        return
    end
    self.stepPause = nil
    self:emit({type = "stepResumed", action = "cancel"})
end
function TestRunner.prototype.stepAction(self, action)
    local point = self.stepPause
    if not point then
        return
    end
    self.stepPause = nil
    if action == "runRest" then
        self.stepping = false
    end
    self.resumePoint = {kind = action == "skipTest" and "skipTest" or "startStepPoint", point = point}
    self:emit({type = "stepResumed", action = action})
end
function TestRunner.prototype.resume(self, resumePoint)
    repeat
        local ____switch33 = resumePoint.kind
        local ____cond33 = ____switch33 == "beforeTest"
        if ____cond33 then
            resumePoint.ticksLeft = resumePoint.ticksLeft - 1
            if resumePoint.ticksLeft > 0 then
                self.resumePoint = resumePoint
                return true
            end
            return self:reachTest(resumePoint.test)
        end
        ____cond33 = ____cond33 or ____switch33 == "asyncPart"
        if ____cond33 then
            return self:pollAsyncPart(resumePoint.testRun, resumePoint.part)
        end
        ____cond33 = ____cond33 or ____switch33 == "startStepPoint"
        if ____cond33 then
            return self:startStepPoint(resumePoint.point)
        end
        ____cond33 = ____cond33 or ____switch33 == "skipTest"
        if ____cond33 then
            self:skipTest(resumePoint.point)
            return false
        end
        ____cond33 = ____cond33 or ____switch33 == "awaitingReload"
        if ____cond33 then
            self:setLoadError("Reload was requested but did not happen. Aborting test run.")
            return true
        end
        do
            assertNever(resumePoint)
        end
    until true
end
function TestRunner.prototype.begin(self)
    if game.is_multiplayer() then
        error("Tests cannot be in run in multiplayer")
    end
    self.status = "running"
    local stage = self.state.store.stage:get()
    if stage == "NotRun" or stage == "Ready" then
        self:startTestRun(false)
    elseif stage == "ReloadingMods" then
        self:resumeAfterReload()
    elseif stage == "Running" then
        self:setLoadError("Save was unexpectedly reloaded while tests were running. This will cause tests to break. Aborting test run.")
    elseif stage == "Finished" or stage == "LoadError" then
        self:startTestRun(true)
    else
        assertNever(stage)
    end
end
function TestRunner.prototype.startTestRun(self, isRerun)
    local state = self.state
    state.isRerun = isRerun
    self.stepping = state.config.step
    state.report = createRunReport()
    state.report.profiler = game.create_profiler()
    state.store.stage:set("Running")
    local ____temp_6 = state.store:persisted()
    local lastFailedTests = ____temp_6.lastFailedTests
    if shouldReorderFailedFirst(state.config, lastFailedTests) then
        reorderFailedFirst(state.suite.rootBlock, lastFailedTests)
    end
    self:emit({type = "testRunStarted"})
    self:enterBlock(state.suite.rootBlock)
    self.cursor = {block = state.suite.rootBlock, index = 0}
    self:advance()
end
function TestRunner.prototype.resumeAfterReload(self)
    local resumePoint = resumeAfterReload(self.state)
    if not resumePoint then
        self:setLoadError("Mod files were changed after reload. Aborting test run.")
        return
    end
    local test = resumePoint.test
    local partIndex = resumePoint.partIndex
    self.stepping = resumePoint.stepping
    self.state.store.stage:set("Running")
    self.cursor = {block = test.parent, index = test.indexInParent + 1}
    local testRun = {test = test, afterTestFuncs = {}}
    if not self:advanceParts(
        testRun,
        self:startPart(testRun, partIndex)
    ) then
        self:advance()
    end
end
function TestRunner.prototype.setLoadError(self, message)
    self.status = "done"
    setToLoadErrorState(self.state, message)
    self:emit({type = "loadError"})
end
function TestRunner.prototype.advance(self)
    while not self.cancelRequested do
        local test = self:nextTest()
        if self.cancelRequested then
            return
        end
        if not test then
            self:endRun({type = "testRunFinished"})
            return
        end
        local ticksBefore = self.stepping and math.max(test.ticksBefore - 1, 0) or test.ticksBefore
        if ticksBefore > 0 then
            self.resumePoint = {kind = "beforeTest", test = test, ticksLeft = ticksBefore}
            return
        end
        if self:reachTest(test) then
            return
        end
    end
end
function TestRunner.prototype.nextTest(self)
    while true do
        do
            if self.cancelRequested then
                return nil
            end
            local cursor = self.cursor
            local block = cursor.block
            if #block.errors > 0 or cursor.index >= #block.children then
                self:leaveBlock(block)
                if not block.parent then
                    self.cursor = nil
                    return nil
                end
                self.cursor = {block = block.parent, index = block.indexInParent + 1}
                goto __continue55
            end
            local child = block.children[cursor.index + 1]
            if child.type == "describeBlock" then
                self:enterBlock(child)
                self.cursor = {block = child, index = 0}
                goto __continue55
            end
            cursor.index = cursor.index + 1
            self:emit({type = "testEntered", test = child})
            if not isSkippedTest(child, self.state) then
                return child
            end
            self:emit(child.mode == "todo" and ({type = "testTodo", test = child}) or ({type = "testSkipped", test = child}))
        end
        ::__continue55::
    end
end
function TestRunner.prototype.enterBlock(self, block)
    self:emit({type = "describeBlockEntered", block = block})
    if #block.errors ~= 0 then
        return
    end
    if #block.children == 0 then
        local ____block_errors_7 = block.errors
        ____block_errors_7[#____block_errors_7 + 1] = "No tests defined"
    end
    if self:hasAnyTest(block) then
        runBlockHooks(block, "beforeAll", true)
    end
end
function TestRunner.prototype.leaveBlock(self, block)
    if self:hasAnyTest(block) then
        runBlockHooks(block, "afterAll", true)
    end
    self:emit(#block.errors > 0 and ({type = "describeBlockFailed", block = block}) or ({type = "describeBlockFinished", block = block}))
end
function TestRunner.prototype.reachTest(self, test)
    if self.stepping then
        self:pause({kind = "testStart", test = test})
        return true
    end
    return self:startAndRunTest(test)
end
function TestRunner.prototype.pause(self, point)
    self.stepPause = point
    self:emit({
        type = "stepPaused",
        test = stepPointTest(point),
        step = point.kind == "stepPart" and stepPartLabel(point.testRun.test, point.partIndex) or nil
    })
end
function TestRunner.prototype.startStepPoint(self, point)
    local ____temp_8
    if point.kind == "testStart" then
        ____temp_8 = self:startAndRunTest(point.test)
    else
        ____temp_8 = self:startStepPart(point.testRun, point.partIndex)
    end
    return ____temp_8
end
function TestRunner.prototype.skipTest(self, point)
    if point.kind == "stepPart" then
        self:closeTestRun(point.testRun, false)
    end
    self:emit({
        type = "testSkippedByUser",
        test = stepPointTest(point)
    })
end
function TestRunner.prototype.startAndRunTest(self, test)
    test.profiler = game.create_profiler()
    local part = newPartRun(0)
    local testRun = {test = test, afterTestFuncs = {}, part = part}
    self.state.currentTestRun = testRun
    self:emit({type = "testStarted", test = test})
    local beforeEach = collectBeforeEachHooks(test.parent)
    for ____, hook in ipairs(beforeEach) do
        if #test.errors ~= 0 then
            break
        end
        local success, message = __factorio_test__pcallWithStacktrace(hook)
        if not success then
            local ____test_errors_9 = test.errors
            ____test_errors_9[#____test_errors_9 + 1] = message
        end
    end
    self:runPart(testRun, part)
    return self:advanceParts(testRun, part)
end
function TestRunner.prototype.startStepPart(self, testRun, partIndex)
    self:emit({
        type = "stepStarted",
        test = testRun.test,
        step = stepPartLabel(testRun.test, partIndex)
    })
    return self:advanceParts(
        testRun,
        self:startPart(testRun, partIndex)
    )
end
function TestRunner.prototype.pollAsyncPart(self, testRun, part)
    local ____testRun_10 = testRun
    local test = ____testRun_10.test
    local ____part_11, ____ticksElapsed_12 = part, "ticksElapsed"
    local ____part_ticksElapsed_13 = ____part_11[____ticksElapsed_12] + 1
    ____part_11[____ticksElapsed_12] = ____part_ticksElapsed_13
    local tickNumber = ____part_ticksElapsed_13
    local timeout = part.timeout
    if tickNumber > timeout then
        pushPartError(
            test,
            part,
            (("Test timed out after " .. tostring(timeout)) .. " ticks:\n") .. formatSource(test.parts[part.partIndex + 1].source)
        )
    end
    if #test.errors == 0 then
        for ____, func in ipairs(__TS__ObjectKeys(part.onTickFuncs)) do
            local success, result = __factorio_test__pcallWithStacktrace(func, tickNumber)
            if not success then
                pushPartError(test, part, result)
                break
            elseif result == false then
                part.onTickFuncs[func] = nil
            end
        end
    end
    return self:advanceParts(testRun, part)
end
function TestRunner.prototype.startPart(self, testRun, partIndex)
    local part = newPartRun(partIndex)
    testRun.part = part
    self:runPart(testRun, part)
    return part
end
function TestRunner.prototype.runPart(self, testRun, part)
    local ____testRun_14 = testRun
    local test = ____testRun_14.test
    self.state.currentTestRun = testRun
    if #test.errors == 0 then
        local success, message = __factorio_test__pcallWithStacktrace(test.parts[part.partIndex + 1].func)
        if not success then
            pushPartError(test, part, message)
        end
    end
end
function TestRunner.prototype.advanceParts(self, testRun, part)
    local ____testRun_15 = testRun
    local test = ____testRun_15.test
    while isPartComplete(test, part) do
        local nextIndex = part.partIndex + 1
        if nextIndex >= #test.parts then
            if self.cancelRequested then
                return true
            end
            self:leaveTest(testRun)
            return false
        end
        local ____test_parts_index_16 = test.parts[nextIndex + 1]
        local reloadBefore = ____test_parts_index_16.reloadBefore
        local step = ____test_parts_index_16.step
        if #test.errors == 0 then
            if reloadBefore then
                if #testRun.afterTestFuncs == 0 then
                    self:beginReload(test, nextIndex, reloadBefore)
                    return true
                end
                local ____test_errors_17 = test.errors
                ____test_errors_17[#____test_errors_17 + 1] = ("after_test cannot be used before a reload (after_reload_" .. reloadBefore) .. ")"
            elseif step then
                self:reachStepPart(testRun, nextIndex)
                return true
            end
        end
        part = self:startPart(testRun, nextIndex)
    end
    self.resumePoint = {kind = "asyncPart", testRun = testRun, part = part}
    return true
end
function TestRunner.prototype.reachStepPart(self, testRun, partIndex)
    testRun.part = nil
    local point = {kind = "stepPart", testRun = testRun, partIndex = partIndex}
    if self.stepping and not self.cancelRequested then
        self:pause(point)
    else
        self.resumePoint = {kind = "startStepPoint", point = point}
    end
end
function TestRunner.prototype.beginReload(self, test, resumePartIndex, kind)
    prepareReload(self.state, {test = test, partIndex = resumePartIndex, stepping = self.stepping})
    self.resumePoint = {kind = "awaitingReload"}
    if kind == "mods" then
        game.reload_mods()
    else
        game.reload_script()
    end
end
function TestRunner.prototype.closeTestRun(self, testRun, recordErrors)
    runAfterEachHooks(testRun, recordErrors)
    self.state.currentTestRun = nil
    local ____opt_18 = testRun.test.profiler
    if ____opt_18 ~= nil then
        ____opt_18.stop()
    end
end
function TestRunner.prototype.leaveTest(self, testRun)
    local ____testRun_20 = testRun
    local test = ____testRun_20.test
    self:closeTestRun(testRun, true)
    if #test.errors == 0 then
        self:emit({type = "testPassed", test = test})
        return
    end
    self:emit({type = "testFailed", test = test})
    local ____self_state_config_21 = self.state.config
    local bail = ____self_state_config_21.bail
    if bail ~= nil then
        self.failureCount = self.failureCount + 1
        if self.failureCount >= bail then
            self.state.report.bailedOut = true
            self:requestCancel()
        end
    end
end
function TestRunner.prototype.endRun(self, event)
    self.status = "done"
    local state = self.state
    local ____opt_22 = state.report.profiler
    if ____opt_22 ~= nil then
        ____opt_22.stop()
    end
    state.store:persisted().lastFailedTests = state.report.failedTestPaths
    state.store.stage:set("Finished")
    self:emit(event)
end
function TestRunner.prototype.cancelRun(self)
    local state = self.state
    local block
    if state.currentTestRun then
        block = state.currentTestRun.test.parent
        self:closeTestRun(state.currentTestRun, false)
    else
        local ____opt_24 = self.cursor
        block = ____opt_24 and ____opt_24.block
    end
    if block == nil then
        block = state.suite.rootBlock
    end
    while block do
        if self:hasAnyTest(block) then
            runBlockHooks(block, "afterAll", false)
        end
        self:emit({type = "describeBlockFinished", block = block})
        block = block.parent
    end
    self:endRun(state.report.bailedOut and ({type = "testRunFinished"}) or ({type = "testRunCancelled"}))
end
function TestRunner.prototype.hasAnyTest(self, block)
    return __TS__ArraySome(
        block.children,
        function(____, child)
            local ____temp_26
            if child.type == "test" then
                ____temp_26 = not isSkippedTest(child, self.state)
            else
                ____temp_26 = self:hasAnyTest(child)
            end
            return ____temp_26
        end
    )
end
return ____exports
 end,
["setup-globals"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local util = require("util")
local ____each_2Dformat = require("each-format")
local createEachItems = ____each_2Dformat.createEachItems
local ____pcall_2Dwith_2Dstacktrace = require("pcall-with-stacktrace")
local __factorio_test__pcallWithStacktrace = ____pcall_2Dwith_2Dstacktrace.__factorio_test__pcallWithStacktrace
local ____state = require("state")
local consumeTags = ____state.consumeTags
local ____test_2Dmode = require("test-mode")
local propagateTestMode = ____test_2Dmode.propagateTestMode
local ____tests = require("tests")
local addDescribeBlock = ____tests.addDescribeBlock
local addTest = ____tests.addTest
local createSource = ____tests.createSource
local function getCallerSource(upStack)
    if upStack == nil then
        upStack = 1
    end
    local info = debug.getinfo(upStack + 2, "Sl") or ({})
    return createSource(info.source, info.currentline)
end
local function getCurrentTestRun(context)
    return context:testState().currentTestRun or error("This can only be called within a test")
end
local function addHook(context, ____type, func)
    local ____table_currentBlock_hooks_0 = context:definition().currentBlock.hooks
    ____table_currentBlock_hooks_0[#____table_currentBlock_hooks_0 + 1] = {type = ____type, func = func}
end
local function afterTest(context, func)
    local ____getCurrentTestRun_result_afterTestFuncs_1 = getCurrentTestRun(context).afterTestFuncs
    ____getCurrentTestRun_result_afterTestFuncs_1[#____getCurrentTestRun_result_afterTestFuncs_1 + 1] = func
end
local function createTest(context, name, func, mode, upStack)
    if upStack == nil then
        upStack = 1
    end
    local definition = context:definition()
    local parent = definition.currentBlock
    return addTest(
        parent,
        name,
        getCallerSource(upStack + 1),
        func,
        mode,
        util.merge({
            consumeTags(definition),
            parent.tags
        })
    )
end
local function countStepParts(test)
    return #__TS__ArrayFilter(
        test.parts,
        function(____, part) return part.step ~= nil end
    )
end
local function addPart(test, func, kind, funcForSource)
    if funcForSource == nil then
        funcForSource = func
    end
    local info = debug.getinfo(funcForSource, "Sl")
    local source = createSource(info.source, info.linedefined)
    if kind.step ~= nil then
        local ____test_parts_2 = test.parts
        ____test_parts_2[#____test_parts_2 + 1] = {
            func = func,
            source = source,
            step = {
                caption = kind.step.caption,
                index = countStepParts(test) + 1
            }
        }
    else
        local ____test_parts_3 = test.parts
        ____test_parts_3[#____test_parts_3 + 1] = {func = func, source = source, reloadBefore = kind.reloadBefore}
    end
end
local function parseStepArgs(captionOrFunc, func, extra)
    if extra == nil then
        if type(captionOrFunc) == "function" and func == nil then
            return {func = captionOrFunc}
        end
        if type(captionOrFunc) == "string" and type(func) == "function" then
            return {caption = captionOrFunc, func = func}
        end
    end
    error("step() takes an optional caption and a function: test(...).step(\"caption\", func) or test(...).step(func)", 3)
end
local function createTestBuilder(addPart, addTag)
    local result
    local function reloadFunc(reloadBefore, tag)
        return function(func)
            addPart(func, {reloadBefore = reloadBefore})
            addTag(tag)
            return result
        end
    end
    result = {
        after_reload_script = reloadFunc("script", "after_reload_script"),
        after_reload_mods = reloadFunc("mods", "after_reload_mods"),
        step = function(captionOrFunc, func, extra)
            local step = parseStepArgs(captionOrFunc, func, extra)
            addPart(step.func, {step = {caption = step.caption}})
            return result
        end
    }
    return result
end
local function createDescribe(context, name, block, mode, upStack)
    if upStack == nil then
        upStack = 1
    end
    local definition = context:definition()
    local source = getCallerSource(upStack + 1)
    local parent = definition.currentBlock
    local describeBlock = addDescribeBlock(
        parent,
        name,
        source,
        mode,
        util.merge({
            parent.tags,
            consumeTags(definition)
        })
    )
    definition.currentBlock = describeBlock
    local success, msg = __factorio_test__pcallWithStacktrace(block)
    if not success then
        local ____describeBlock_errors_4 = describeBlock.errors
        ____describeBlock_errors_4[#____describeBlock_errors_4 + 1] = "Error in definition: " .. tostring(msg)
    end
    propagateTestMode(definition, describeBlock, mode)
    definition.currentBlock = parent
    if definition.currentTags then
        local ____describeBlock_errors_5 = describeBlock.errors
        ____describeBlock_errors_5[#____describeBlock_errors_5 + 1] = "Tags not added to any test or describe block: " .. serpent.line(definition.currentTags)
        definition.currentTags = nil
    end
    return describeBlock
end
local function createTestEach(context, mode)
    local result = setmetatable(
        {},
        {__call = function(____, name, func)
            local test = createTest(context, name, func, mode)
            return createTestBuilder(
                function(func1, kind) return addPart(test, func1, kind) end,
                function(tag)
                    test.tags[tag] = true
                    return nil
                end
            )
        end}
    )
    result.each = function(values) return function(name, func)
        local items = createEachItems(values, name)
        local testBuilders = __TS__ArrayMap(
            items,
            function(____, item)
                local test = createTest(
                    context,
                    item.name,
                    function() return func(table.unpack(item.row)) end,
                    mode,
                    3
                )
                return {test = test, row = item.row}
            end
        )
        return createTestBuilder(
            function(func, kind)
                for ____, ____value in ipairs(testBuilders) do
                    local test = ____value.test
                    local row = ____value.row
                    addPart(
                        test,
                        function()
                            func(table.unpack(row))
                        end,
                        kind,
                        func
                    )
                end
            end,
            function(tag)
                for ____, ____value in ipairs(testBuilders) do
                    local test = ____value.test
                    test.tags[tag] = true
                end
            end
        )
    end end
    return result
end
local function createDescribeEach(context, mode)
    local result = setmetatable(
        {},
        {__call = function(____, name, func)
            local block = createDescribe(context, name, func, mode)
            return block
        end}
    )
    result.each = function(values) return function(name, func)
        local items = createEachItems(values, name)
        for ____, ____value in ipairs(items) do
            local row = ____value.row
            local name = ____value.name
            createDescribe(
                context,
                name,
                function() return func(table.unpack(row)) end,
                mode,
                2
            )
        end
    end end
    return result
end
local function createTestCreator(context)
    local test = createTestEach(context, nil)
    test.skip = createTestEach(context, "skip")
    test.only = createTestEach(context, "only")
    test.todo = function(name)
        createTest(
            context,
            name,
            function()
            end,
            "todo"
        )
    end
    return test
end
local function createDescribeCreator(context)
    local describe = createDescribeEach(context, nil)
    describe.skip = createDescribeEach(context, "skip")
    describe.only = createDescribeEach(context, "only")
    return describe
end
local function tags(context, tags)
    local definition = context:definition()
    if definition.currentTags then
        local ____definition_currentBlock_errors_6 = definition.currentBlock.errors
        ____definition_currentBlock_errors_6[#____definition_currentBlock_errors_6 + 1] = "Double call to tags()"
    end
    definition.currentTags = util.list_to_map(tags)
end
local function getCurrentPart(context, funcName)
    return getCurrentTestRun(context).part or error(funcName .. "() cannot be called between test parts")
end
local function implicitAsync(context, part)
    part.async = true
    if not part.explicitAsync then
        part.timeout = context:testState().config.default_timeout
    end
end
local function async(context, timeout)
    local part = getCurrentPart(context, "async")
    part.async = true
    part.explicitAsync = true
    if not timeout then
        timeout = context:testState().config.default_timeout
    end
    if timeout < 1 then
        error("test timeout must be greater than 0")
    end
    part.timeout = timeout
end
local function done(context)
    local part = getCurrentPart(context, "done")
    if not part.async then
        error("\"done\" can only be used when test is async")
    end
    part.asyncDone = true
end
local function addOnTick(context, part, func)
    implicitAsync(context, part)
    part.onTickFuncs[func] = true
end
local function onTick(context, func)
    addOnTick(
        context,
        getCurrentPart(context, "on_tick"),
        func
    )
end
local function afterTicks(context, ticks, func)
    local part = getCurrentPart(context, "after_ticks")
    if ticks < 1 then
        error("after_ticks amount must be positive")
    end
    local finishTick = part.ticksElapsed + ticks
    addOnTick(
        context,
        part,
        function(tick)
            if tick >= finishTick then
                func()
                return false
            end
        end
    )
end
local function ticksBetweenTests(context, ticks)
    if ticks < 0 then
        error("ticks between tests must be 0 or greater")
    end
    context:definition().currentBlock.ticksBetweenTests = ticks
end
function ____exports.createTestApi(context)
    local test = createTestCreator(context)
    return {
        test = test,
        it = test,
        describe = createDescribeCreator(context),
        tags = function(...)
            local tagNames = {...}
            return tags(context, tagNames)
        end,
        before_all = function(func) return addHook(context, "beforeAll", func) end,
        after_all = function(func) return addHook(context, "afterAll", func) end,
        before_each = function(func) return addHook(context, "beforeEach", func) end,
        after_each = function(func) return addHook(context, "afterEach", func) end,
        after_test = function(func) return afterTest(context, func) end,
        async = function(timeout) return async(context, timeout) end,
        done = function() return done(context) end,
        on_tick = function(func) return onTick(context, func) end,
        after_ticks = function(ticks, func) return afterTicks(context, ticks, func) end,
        ticks_between_tests = function(ticks) return ticksBetweenTests(context, ticks) end
    }
end
return ____exports
 end,
["test-gui"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local buildTestSummary, updateTestCounts, setStepControlsVisible, showRunning, setStepButtonsEnabled, showRunEnded
local ____util = require("shared.util")
local getPlayer = ____util.getPlayer
local ____storage = require("storage")
local testStorage = ____storage.testStorage
local ____tests = require("tests")
local countActiveTests = ____tests.countActiveTests
function buildTestSummary(results)
    local parts = {}
    if results.passed > 0 then
        parts[#parts + 1] = {"factorio-test.progress-gui.n-passed", results.passed}
    end
    if results.failed > 0 then
        parts[#parts + 1] = {"factorio-test.progress-gui.n-failed", results.failed}
    end
    if results.describeBlockErrors > 0 then
        parts[#parts + 1] = {"factorio-test.progress-gui.n-errors", results.describeBlockErrors}
    end
    if results.skipped > 0 then
        parts[#parts + 1] = {"factorio-test.progress-gui.n-skipped", results.skipped}
    end
    if results.todo > 0 then
        parts[#parts + 1] = {"factorio-test.progress-gui.n-todo", results.todo}
    end
    if #parts == 0 then
        return ""
    end
    local result = {""}
    for i, part in ipairs(parts) do
        if i > 1 then
            result[#result + 1] = ", "
        end
        result[#result + 1] = part
    end
    return result
end
function updateTestCounts(gui, results)
    gui.progressBar.value = gui.totalTests == 0 and 1 or results.ran / gui.totalTests
    gui.progressLabel.caption = {"", results.ran, "/", gui.totalTests}
    gui.testSummary.caption = buildTestSummary(results)
end
function setStepControlsVisible(gui, visible)
    gui.nextRow.visible = visible
    gui.stepControls.visible = visible
end
function showRunning(gui, caption)
    gui.statusText.caption = caption
    gui.lastRunCaption = caption
end
function setStepButtonsEnabled(gui, enabled)
    for ____, button in ipairs(gui.stepButtons.children) do
        if button.enabled ~= enabled then
            button.enabled = enabled
        end
    end
end
function showRunEnded(gui, statusLocale)
    setStepControlsVisible(gui, false)
    gui.statusText.caption = {statusLocale}
    gui.actionButton.caption = {"factorio-test.config-gui.rerun-tests"}
    gui.actionButton.tags = {modName = "factorio-test", on_gui_click = "start-tests"}
end
local function StatusText(parent)
    local statusText = parent.add({type = "label"})
    statusText.style.font = "default-large"
    return statusText
end
local function NextRow(parent)
    local nextRow = parent.add({type = "flow", direction = "horizontal"})
    nextRow.visible = false
    nextRow.style.minimal_height = 20
    local nextKindLabel = nextRow.add({type = "label", style = "caption_label"})
    local nextLabel = nextRow.add({type = "label"})
    local nextStyle = nextLabel.style
    nextStyle.single_line = false
    nextStyle.maximal_width = 500
    return {nextRow = nextRow, nextKindLabel = nextKindLabel, nextLabel = nextLabel}
end
local function ProgressBar(parent)
    local progressFlow = parent.add({type = "flow", direction = "horizontal"})
    progressFlow.style.horizontally_stretchable = true
    progressFlow.style.vertical_align = "center"
    local progressBar = progressFlow.add({type = "progressbar"})
    progressBar.style.horizontally_stretchable = true
    local progressLabel = progressFlow.add({type = "label"})
    local plStyle = progressLabel.style
    plStyle.width = 80
    plStyle.horizontal_align = "center"
    return {progressBar = progressBar, progressLabel = progressLabel}
end
local function TestSummary(parent)
    local label = parent.add({type = "label"})
    label.style.font = "default-bold"
    return label
end
local function stepButton(parent, caption, action, style)
    if style == nil then
        style = "dialog_button"
    end
    parent.add({type = "button", caption = {caption}, style = style, tags = {modName = "factorio-test", on_gui_click = "step-action", stepAction = action}})
end
local function StepControls(parent)
    local stepControls = parent.add({type = "flow", direction = "vertical"})
    stepControls.visible = false
    stepControls.style.vertical_spacing = 12
    stepControls.add({type = "line", direction = "horizontal", style = "inside_shallow_frame_with_padding_line"})
    local stepButtons = stepControls.add({type = "flow", direction = "horizontal"})
    local buttonsStyle = stepButtons.style
    buttonsStyle.horizontally_stretchable = true
    buttonsStyle.horizontal_align = "right"
    buttonsStyle.vertical_align = "center"
    stepButton(stepButtons, "factorio-test.progress-gui.step-skip-test", "skipTest")
    stepButton(stepButtons, "factorio-test.progress-gui.step-run-rest", "runRest")
    stepButton(stepButtons, "factorio-test.progress-gui.step-continue", "continue", "confirm_button")
    return {stepControls = stepControls, stepButtons = stepButtons}
end
local function TestOutput(parent)
    local frame = parent.add({type = "frame", style = "inside_shallow_frame", direction = "vertical"})
    local pane = frame.add({type = "scroll-pane", style = "scroll_pane_in_shallow_frame"})
    pane.style.height = 600
    pane.style.horizontally_stretchable = true
    return pane
end
local function bottomButtonsBar(parent)
    local flow = parent.add({type = "flow", direction = "horizontal"})
    local spacer = flow.add({type = "empty-widget"})
    spacer.style.horizontally_stretchable = true
    local actionButton = flow.add({type = "button", caption = {"factorio-test.progress-gui.cancel"}, tags = {modName = "factorio-test", on_gui_click = "cancel-test-run"}})
    return {actionButton = actionButton}
end
local function createTestProgressGui(state)
    local player = getPlayer()
    local screen = player.gui.screen
    local ____opt_0 = screen["factorio-test-test-gui"]
    if ____opt_0 ~= nil then
        ____opt_0.destroy()
    end
    local mainFrame = screen.add({type = "frame", name = "factorio-test-test-gui", direction = "vertical"})
    mainFrame.auto_center = true
    mainFrame.style.width = 1000
    local titleBar = mainFrame.add({type = "flow", direction = "horizontal"})
    titleBar.drag_target = mainFrame
    local style = titleBar.style
    style.horizontal_spacing = 8
    style.height = 28
    local targetName = script.mod_name == "level" and script.level.level_name or script.mod_name
    titleBar.add({type = "label", caption = state.suite.hasFocusedTests and ({"", {"factorio-test.progress-gui.title", targetName}, " (.only)"}) or ({"factorio-test.progress-gui.title", targetName}), style = "frame_title", ignored_by_interaction = true})
    do
        local element = titleBar.add({type = "empty-widget", ignored_by_interaction = true, style = "draggable_space"})
        local style = element.style
        style.horizontally_stretchable = true
        style.height = 24
    end
    titleBar.add({
        type = "sprite-button",
        style = "frame_action_button",
        sprite = "utility/close",
        hovered_sprite = "utility/close_black",
        clicked_sprite = "utility/close_black",
        tooltip = {"gui.close"},
        mouse_button_filter = {"left"},
        tags = {modName = "factorio-test", on_gui_click = "close-test-gui"}
    })
    local contentFlow = mainFrame.add({type = "flow", direction = "vertical"})
    contentFlow.style.vertical_spacing = 15
    local topFrame = contentFlow.add({type = "frame", style = "inside_shallow_frame_with_padding", direction = "vertical"})
    local gui = __TS__ObjectAssign(
        {
            player = player,
            mainFrame = mainFrame,
            totalTests = countActiveTests(state),
            statusText = StatusText(topFrame)
        },
        NextRow(topFrame),
        ProgressBar(topFrame),
        {testSummary = TestSummary(topFrame)},
        StepControls(topFrame),
        {output = TestOutput(contentFlow)},
        bottomButtonsBar(contentFlow)
    )
    updateTestCounts(gui, state.report.results)
    return gui
end
local function getTestProgressGui()
    local gui = testStorage().gui
    if not (gui and gui.mainFrame.valid) then
        testStorage().gui = nil
        return nil
    end
    return gui
end
____exports.progressGuiListener = function(event, state)
    if event.type == "testRunStarted" then
        testStorage().gui = createTestProgressGui(state)
        return
    end
    local gui = getTestProgressGui()
    if not gui then
        return
    end
    repeat
        local ____switch27 = event.type
        local ____cond27 = ____switch27 == "describeBlockEntered"
        if ____cond27 then
            do
                local ____event_4 = event
                local block = ____event_4.block
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", block.path}
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "testEntered"
        if ____cond27 then
            do
                local ____event_5 = event
                local test = ____event_5.test
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", test.path}
                break
            end
        end
        ____cond27 = ____cond27 or (____switch27 == "testFailed" or ____switch27 == "testPassed" or ____switch27 == "testSkipped" or ____switch27 == "testTodo")
        if ____cond27 then
            do
                updateTestCounts(gui, state.report.results)
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", event.test.parent.path}
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "testSkippedByUser"
        if ____cond27 then
            do
                gui.totalTests = gui.totalTests - 1
                updateTestCounts(gui, state.report.results)
                gui.statusText.caption = {"factorio-test.progress-gui.running-test", event.test.parent.path}
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "testStarted"
        if ____cond27 then
            showRunning(gui, {"factorio-test.progress-gui.running-test", event.test.path})
            break
        end
        ____cond27 = ____cond27 or ____switch27 == "stepStarted"
        if ____cond27 then
            showRunning(gui, {"factorio-test.progress-gui.running-step", event.test.path, event.step})
            break
        end
        ____cond27 = ____cond27 or ____switch27 == "stepPaused"
        if ____cond27 then
            do
                local ____event_6 = event
                local test = ____event_6.test
                local step = ____event_6.step
                local ____gui_statusText_8 = gui.statusText
                local ____gui_lastRunCaption_7 = gui.lastRunCaption
                if ____gui_lastRunCaption_7 == nil then
                    ____gui_lastRunCaption_7 = {"factorio-test.progress-gui.running-test", test.parent.path}
                end
                ____gui_statusText_8.caption = ____gui_lastRunCaption_7
                gui.nextKindLabel.caption = {step and "factorio-test.progress-gui.step-next-step" or "factorio-test.progress-gui.step-next-test"}
                gui.nextLabel.caption = step or test.path
                setStepControlsVisible(gui, true)
                setStepButtonsEnabled(gui, true)
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "stepResumed"
        if ____cond27 then
            gui.nextKindLabel.caption = ""
            gui.nextLabel.caption = ""
            if event.action == "runRest" or event.action == "cancel" then
                setStepControlsVisible(gui, false)
            end
            break
        end
        ____cond27 = ____cond27 or ____switch27 == "describeBlockFinished"
        if ____cond27 then
            do
                local ____event_9 = event
                local block = ____event_9.block
                if block.parent then
                    gui.statusText.caption = {"factorio-test.progress-gui.running-test", block.parent.path}
                end
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "describeBlockFailed"
        if ____cond27 then
            do
                updateTestCounts(gui, state.report.results)
                local ____event_10 = event
                local block = ____event_10.block
                if block.parent then
                    gui.statusText.caption = {"factorio-test.progress-gui.running-test", block.parent.path}
                end
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "testRunFinished"
        if ____cond27 then
            do
                local statusLocale = state.report.results.status == "passed" and "factorio-test.progress-gui.tests-passed" or (state.report.results.status == "todo" and "factorio-test.progress-gui.tests-passed-with-todo" or "factorio-test.progress-gui.tests-failed")
                showRunEnded(gui, statusLocale)
                break
            end
        end
        ____cond27 = ____cond27 or ____switch27 == "testRunCancelled"
        if ____cond27 then
            showRunEnded(gui, "factorio-test.progress-gui.tests-cancelled")
            break
        end
        ____cond27 = ____cond27 or ____switch27 == "loadError"
        if ____cond27 then
            showRunEnded(gui, "factorio-test.progress-gui.load-error")
            break
        end
    until true
end
--- Called after each runner tick that ends unpaused: a step that re-pauses within its tick never disables buttons.
function ____exports.showStepRunning()
    local gui = getTestProgressGui()
    if gui and gui.stepControls.visible then
        setStepButtonsEnabled(gui, false)
    end
end
function ____exports.hideStepControls()
    local gui = getTestProgressGui()
    if gui then
        setStepControlsVisible(gui, false)
    end
end
local profilerLength = #"(Duration: 0.082400ms)" - #"(<Profiler>)"
____exports.progressGuiLogger = function(message)
    local gui = testStorage().gui
    if not gui or not gui.progressBar.valid then
        return
    end
    local output = gui.output
    local textBox = output.add({type = "text-box", style = "factorio-test-test-output-box-style"})
    textBox.read_only = true
    textBox.word_wrap = true
    local lines = 0
    local isFirstLine = true
    for ____, line in ipairs(__TS__StringSplit(message.plainText, "\n")) do
        local lineLength = #line + (isFirstLine and profilerLength or 0)
        if lineLength > 110 then
            lines = lines + math.ceil(lineLength / 105)
        else
            lines = lines + 1
        end
        isFirstLine = false
    end
    textBox.style.height = 20 * lines
    textBox.caption = message.richText
end
return ____exports
 end,
["storage"] = function(...) 
--[[ Generated with https://github.com/TypeScriptToLua/TypeScriptToLua ]]
local ____exports = {}
function ____exports.testStorage()
    local ____storage_0, ____factorio_test_1 = storage, "__factorio_test"
    if ____storage_0[____factorio_test_1] == nil then
        ____storage_0[____factorio_test_1] = {}
    end
    return storage.__factorio_test
end
return ____exports
 end,
["load"] = function(...) 
local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local __TS__ArrayPush = ____lualib.__TS__ArrayPush
local isRunning, loadTests, createMessageHandlers, createTestListeners, initializeFailedTestsFromConfig, tryContinueTests, runTests, cancelTestRun, stepAction, doRunTests, tapEvent, revertTappedEvents, storageRunStore, testContext, currentRunner, tappedHandlers, oldScript
local util = require("util")
local ____builtin_2Dtest_2Devent_2Dlisteners = require("builtin-test-event-listeners")
local gameEnvironmentListener = ____builtin_2Dtest_2Devent_2Dlisteners.gameEnvironmentListener
local resultListener = ____builtin_2Dtest_2Devent_2Dlisteners.resultListener
local ____cli_2Devents = require("cli-events")
local cliEventEmitter = ____cli_2Devents.cliEventEmitter
local ____config = require("config")
local disableStepIfHeadless = ____config.disableStepIfHeadless
local resolveConfig = ____config.resolveConfig
local ____output = require("output")
local createLogListener = ____output.createLogListener
local debugAdapterLogger = ____output.debugAdapterLogger
local logLogger = ____output.logLogger
local ____runner = require("runner")
local TestRunner = ____runner.TestRunner
local ____setup_2Dglobals = require("setup-globals")
local createTestApi = ____setup_2Dglobals.createTestApi
local ____auto_2Dstart_2Dconfig = require("shared.auto-start-config")
local getAutoStartConfig = ____auto_2Dstart_2Dconfig.getAutoStartConfig
local getAutoStartMod = ____auto_2Dstart_2Dconfig.getAutoStartMod
local isHeadlessMode = ____auto_2Dstart_2Dconfig.isHeadlessMode
local ____util = require("shared.util")
local debugAdapterEnabled = ____util.debugAdapterEnabled
local ____state = require("state")
local TestContext = ____state.TestContext
local ____storage = require("storage")
local testStorage = ____storage.testStorage
local ____test_2Dgui = require("test-gui")
local hideStepControls = ____test_2Dgui.hideStepControls
local progressGuiListener = ____test_2Dgui.progressGuiListener
local progressGuiLogger = ____test_2Dgui.progressGuiLogger
local showStepRunning = ____test_2Dgui.showStepRunning
function isRunning()
    local stage = testContext.store.stage:get()
    return not (stage == "NotRun" or stage == "LoadError" or stage == "Finished")
end
function loadTests(files, partialConfig)
    local ____disableStepIfHeadless_result_0 = disableStepIfHeadless(
        resolveConfig(partialConfig),
        isHeadlessMode()
    )
    local config = ____disableStepIfHeadless_result_0.config
    local warning = ____disableStepIfHeadless_result_0.warning
    if warning then
        log(warning)
    end
    if config.load_luassert then
        debug.getmetatable = getmetatable
        require("__factorio-test__.luassert.init")
    end
    local context = __TS__New(TestContext, storageRunStore)
    local globals = createTestApi(context)
    local defineGlobal = __DebugAdapter and __DebugAdapter.defineGlobal
    if defineGlobal then
        for key in pairs(globals) do
            defineGlobal(nil, key)
        end
    end
    for key, value in pairs(globals) do
        _G[key] = value
    end
    local modToTest = getAutoStartMod() or settings.global["factorio-test-mod-to-test"].value
    local _require = modToTest == "factorio-test" and require or ____originalRequire
    context:beginDefinition(config)
    for ____, file in ipairs(files) do
        globals.describe(
            file,
            function() return _require(file) end
        )
    end
    context:endDefinition()
    return context
end
function createMessageHandlers(headless)
    local handlers = {}
    if not headless then
        handlers[#handlers + 1] = progressGuiLogger
    end
    if debugAdapterEnabled then
        handlers[#handlers + 1] = debugAdapterLogger
    elseif not headless then
        handlers[#handlers + 1] = logLogger
    end
    return handlers
end
function createTestListeners(headless)
    local listeners = {}
    if headless then
        listeners[#listeners + 1] = cliEventEmitter
    end
    __TS__ArrayPush(listeners, gameEnvironmentListener, resultListener)
    listeners[#listeners + 1] = createLogListener(createMessageHandlers(headless))
    if not headless then
        listeners[#listeners + 1] = progressGuiListener
    end
    return listeners
end
function initializeFailedTestsFromConfig()
    local storage = testStorage()
    if storage.lastFailedTests ~= nil then
        return
    end
    local fromConfig = getAutoStartConfig().last_failed_tests
    if fromConfig and #fromConfig > 0 then
        storage.lastFailedTests = util.list_to_map(fromConfig)
    end
end
function tryContinueTests()
    local testStage = testContext.store.stage:get()
    if testStage == "Running" or testStage == "ReloadingMods" then
        doRunTests()
    else
        revertTappedEvents()
    end
end
function runTests()
    if isRunning() then
        return
    end
    log("Running tests for " .. script.mod_name)
    testContext.store.stage:set("Ready")
    doRunTests()
end
function cancelTestRun()
    if currentRunner ~= nil then
        currentRunner:requestCancel()
    end
end
function stepAction(action)
    if currentRunner then
        currentRunner:stepAction(action)
        return
    end
    game.tick_paused = false
    hideStepControls()
end
function doRunTests()
    initializeFailedTestsFromConfig()
    if game ~= nil then
        game.tick_paused = false
    end
    local testListeners = createTestListeners(isHeadlessMode())
    local runner = __TS__New(
        TestRunner,
        testContext:testState(),
        testListeners
    )
    currentRunner = runner
    tapEvent(
        defines.events.on_tick,
        function()
            runner:tick()
            if runner:isDone() then
                currentRunner = nil
                revertTappedEvents()
            elseif game ~= nil and not runner:isStepPaused() then
                game.tick_paused = false
                showStepRunning()
            end
        end
    )
end
function tapEvent(event, func)
    local existing = tappedHandlers[event]
    if existing then
        existing.ours = func
    else
        tappedHandlers[event] = {
            original = script.get_event_handler(event),
            ours = func
        }
        oldScript.on_event(
            event,
            function(data)
                local handlers = tappedHandlers[event]
                local ____opt_5 = handlers.original
                if ____opt_5 ~= nil then
                    ____opt_5(data)
                end
                handlers.ours()
            end
        )
    end
    if rawequal(script, oldScript) then
        local proxyScript = {on_event = function(event, func)
            local handler = tappedHandlers[event]
            if handler then
                handler.original = func
            else
                oldScript.on_event(event, func)
            end
        end}
        setmetatable(proxyScript, {__index = oldScript, __newindex = oldScript})
        _G.script = proxyScript
    end
end
function revertTappedEvents()
    _G.script = oldScript
    for event, handler in pairs(tappedHandlers) do
        tappedHandlers[event] = nil
        script.on_event(event, handler.original)
    end
end
local onTestStageChanged = script.generate_event_name()
storageRunStore = {
    stage = {
        get = function() return testStorage().testStage or "NotRun" end,
        set = function(____, stage)
            testStorage().testStage = stage
            script.raise_event(onTestStageChanged, {stage = stage})
        end
    },
    persisted = function() return testStorage() end
}
local function ____exports(files, config)
    testContext = loadTests(files, config)
    remote.add_interface(
        "factorio-test",
        {
            runTests = runTests,
            cancelTestRun = cancelTestRun,
            stepAction = stepAction,
            modName = function() return script.mod_name end,
            getTestStage = function() return testContext.store.stage:get() end,
            isRunning = isRunning,
            onTestStageChanged = function() return onTestStageChanged end,
            getResults = function() return testContext:testState().report.results end,
            getConfig = function() return testContext:testState().config end
        }
    )
    tapEvent(defines.events.on_tick, tryContinueTests)
end
tappedHandlers = {}
oldScript = script
return ____exports
 end,
}
return require("load", ...)
