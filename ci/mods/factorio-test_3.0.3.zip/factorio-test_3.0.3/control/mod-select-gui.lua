local ____lualib = require("lualib_bundle")
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["8"] = 20,["9"] = 1,["10"] = 3,["11"] = 3,["12"] = 4,["13"] = 4,["14"] = 5,["15"] = 5,["16"] = 39,["17"] = 40,["18"] = 40,["19"] = 40,["20"] = 40,["21"] = 40,["23"] = 40,["25"] = 50,["26"] = 51,["27"] = 51,["28"] = 51,["29"] = 51,["30"] = 52,["31"] = 52,["32"] = 52,["33"] = 52,["34"] = 53,["35"] = 53,["36"] = 53,["37"] = 53,["38"] = 54,["39"] = 55,["40"] = 56,["42"] = 58,["43"] = 59,["44"] = 60,["46"] = 63,["47"] = 64,["48"] = 68,["49"] = 70,["50"] = 71,["51"] = 72,["52"] = 73,["54"] = 82,["55"] = 87,["56"] = 88,["57"] = 89,["60"] = 93,["61"] = 93,["62"] = 93,["63"] = 93,["64"] = 93,["65"] = 93,["66"] = 93,["67"] = 93,["68"] = 93,["69"] = 93,["72"] = 114,["73"] = 115,["75"] = 118,["76"] = 119,["77"] = 123,["78"] = 129,["79"] = 134,["80"] = 134,["81"] = 134,["82"] = 136,["83"] = 144,["84"] = 146,["85"] = 147,["86"] = 148,["87"] = 150,["88"] = 150,["89"] = 150,["90"] = 150,["91"] = 150,["92"] = 150,["93"] = 150,["94"] = 161,["95"] = 162,["96"] = 163,["97"] = 164,["98"] = 165,["99"] = 166,["100"] = 167,["103"] = 182,["104"] = 183,["105"] = 183,["106"] = 184,["108"] = 186,["109"] = 187,["110"] = 196,["111"] = 198,["112"] = 199,["114"] = 207,["115"] = 208,["116"] = 209,["119"] = 210,["120"] = 211,["122"] = 234,["123"] = 235,["124"] = 237,["125"] = 242,["126"] = 247,["127"] = 251,["128"] = 251,["129"] = 251,["130"] = 251,["131"] = 251,["132"] = 251,["133"] = 251,["135"] = 260,["136"] = 261,["139"] = 262,["140"] = 264,["141"] = 265,["142"] = 267,["143"] = 269,["144"] = 271,["145"] = 272,["146"] = 274,["147"] = 275,["149"] = 286,["150"] = 287,["151"] = 288,["152"] = 289,["154"] = 291,["156"] = 291,["158"] = 292,["159"] = 294,["160"] = 299,["161"] = 301,["162"] = 303,["163"] = 304,["164"] = 305,["165"] = 306,["166"] = 307,["168"] = 310,["169"] = 311,["172"] = 312,["173"] = 313,["174"] = 314,["175"] = 315,["176"] = 316,["179"] = 345,["180"] = 346,["183"] = 347,["184"] = 348,["185"] = 349,["187"] = 349,["190"] = 20,["191"] = 21,["192"] = 23,["193"] = 43,["194"] = 109,["195"] = 110,["196"] = 111,["197"] = 109,["198"] = 171,["199"] = 171,["200"] = 171,["201"] = 172,["202"] = 172,["203"] = 172,["204"] = 173,["205"] = 174,["206"] = 175,["208"] = 177,["210"] = 179,["211"] = 171,["212"] = 171,["213"] = 202,["214"] = 202,["215"] = 202,["216"] = 203,["217"] = 204,["218"] = 202,["219"] = 202,["220"] = 214,["221"] = 215,["222"] = 215,["223"] = 215,["224"] = 216,["225"] = 217,["226"] = 215,["227"] = 215,["228"] = 220,["229"] = 220,["230"] = 220,["231"] = 221,["232"] = 222,["235"] = 225,["236"] = 220,["237"] = 220,["238"] = 228,["239"] = 228,["240"] = 228,["241"] = 229,["242"] = 230,["243"] = 231,["244"] = 228,["245"] = 228,["246"] = 278,["247"] = 279,["248"] = 279,["249"] = 280,["250"] = 281,["251"] = 282,["253"] = 278,["254"] = 320,["255"] = 322,["256"] = 322,["257"] = 322,["258"] = 323,["259"] = 324,["261"] = 326,["262"] = 322,["263"] = 322,["264"] = 329,["265"] = 330,["266"] = 331,["268"] = 331,["270"] = 332,["271"] = 332,["272"] = 332,["273"] = 332,["274"] = 332,["275"] = 332,["276"] = 332,["277"] = 332,["278"] = 329,["279"] = 352,["280"] = 353,["281"] = 354,["283"] = 352,["284"] = 358,["285"] = 359,["286"] = 360,["287"] = 361,["288"] = 359,["289"] = 363,["290"] = 363,["291"] = 363,["292"] = 363});
local ____exports = {}
local modSelectGuiValid, getModDropdownItems, TitleBar, getTestMod, ModSelect, createModTextField, destroyModTextField, TestStageBar, updateConfigGui, createConfigGui, destroyConfigGui, refreshConfigGui, ModSelectGuiName, ModSelectWidth, thisModName, LevelId, OnModSelectionChanged, OnModTextfieldChanged, ReloadMods, RunTests, DestroyConfigGui
local modGui = require("mod-gui")
local ____guiAction = require("control.guiAction")
local guiAction = ____guiAction.guiAction
local ____post_2Dload_2Daction = require("control.post-load-action")
local postLoadAction = ____post_2Dload_2Daction.postLoadAction
local ____start_2Dtests = require("control.start-tests")
local startTests = ____start_2Dtests.startTests
function modSelectGuiValid()
    local ____opt_2 = storage.modSelectGui
    local ____opt_0 = ____opt_2 and ____opt_2.mainFrame
    local ____temp_4 = ____opt_0 and ____opt_0.valid
    if ____temp_4 == nil then
        ____temp_4 = false
    end
    return ____temp_4
end
function getModDropdownItems()
    local mods = __TS__ArrayFilter(
        __TS__ObjectKeys(script.active_mods),
        function(____, mod) return remote.interfaces["factorio-test-tests-available-for-" .. mod] end
    )
    local labels = {
        {"factorio-test.config-gui.none"},
        table.unpack(mods)
    }
    local values = {
        "",
        table.unpack(mods)
    }
    if remote.interfaces["factorio-test-tests-available-for-" .. LevelId] then
        labels[#labels + 1] = {"factorio-test.config-gui.scenario", script.level.level_name}
        values[#values + 1] = LevelId
    end
    labels[#labels + 1] = {"factorio-test.config-gui.other"}
    values[#values + 1] = ""
    return {labels = labels, values = values}
end
function TitleBar(parent, title)
    local titleBar = parent.add({type = "flow", direction = "horizontal"})
    titleBar.drag_target = parent
    local style = titleBar.style
    style.horizontal_spacing = 8
    style.height = 28
    titleBar.add({type = "label", caption = title, style = "frame_title", ignored_by_interaction = true})
    do
        local element = titleBar.add({type = "empty-widget", ignored_by_interaction = true, style = "draggable_space"})
        local style = element.style
        style.horizontally_stretchable = true
        style.height = 24
    end
    do
        titleBar.add({
            type = "sprite-button",
            style = "frame_action_button",
            sprite = "utility/close",
            hovered_sprite = "utility/close_black",
            clicked_sprite = "utility/close_black",
            tooltip = {"gui.close"},
            mouse_button_filter = {"left"},
            tags = {modName = thisModName, on_gui_click = DestroyConfigGui}
        })
    end
end
function getTestMod()
    return settings.global["factorio-test-mod-to-test"].value
end
function ModSelect(parent)
    local mainFlow = parent.add({type = "flow", direction = "horizontal"})
    mainFlow.add({type = "label", style = "caption_label", caption = {"factorio-test.config-gui.load-tests-for"}})
    local selectFlow = mainFlow.add({type = "flow", direction = "vertical"})
    local ____getModDropdownItems_result_5 = getModDropdownItems()
    local labels = ____getModDropdownItems_result_5.labels
    local values = ____getModDropdownItems_result_5.values
    local modSelect = selectFlow.add({type = "drop-down", items = labels, tags = {modName = thisModName, on_gui_selection_state_changed = OnModSelectionChanged}})
    modSelect.style.minimal_width = ModSelectWidth
    local configGui = storage.modSelectGui
    configGui.modSelect = modSelect
    configGui.modSelectValues = values
    configGui.refreshButton = mainFlow.add({
        type = "sprite-button",
        style = "tool_button",
        sprite = "utility/refresh",
        tooltip = {"factorio-test.config-gui.reload-mods"},
        tags = {modName = thisModName, on_gui_click = ReloadMods}
    })
    local testMod = getTestMod()
    local foundIndex = __TS__ArrayIndexOf(values, testMod)
    local otherIndex = #values
    local modSelectedIndex = testMod == "" and 1 or (foundIndex ~= -1 and foundIndex + 1 or otherIndex)
    modSelect.selected_index = modSelectedIndex
    if modSelectedIndex == otherIndex then
        createModTextField().text = testMod
    end
end
function createModTextField()
    local ____opt_7 = storage.modSelectGui.modTextField
    if ____opt_7 and ____opt_7.valid then
        return storage.modSelectGui.modTextField
    end
    local modSelect = storage.modSelectGui.modSelect
    local textfield = modSelect.parent.add({type = "textfield", lose_focus_on_confirm = true, tags = {modName = thisModName, on_gui_text_changed = OnModTextfieldChanged}, index = 2})
    textfield.style.width = ModSelectWidth
    storage.modSelectGui.modTextField = textfield
    return textfield
end
function destroyModTextField()
    local configGui = storage.modSelectGui
    if not configGui.modTextField then
        return
    end
    configGui.modTextField.destroy()
    configGui.modTextField = nil
end
function TestStageBar(parent)
    local configGui = storage.modSelectGui
    local mainFlow = parent.add({type = "flow", direction = "vertical"})
    local buttonFlow = mainFlow.add({type = "flow", direction = "horizontal"})
    buttonFlow.add({type = "empty-widget"}).style.horizontally_stretchable = true
    configGui.runButton = buttonFlow.add({
        type = "button",
        name = "runTests",
        style = "green_button",
        caption = {"factorio-test.config-gui.run-tests"},
        tags = {modName = thisModName, on_gui_click = RunTests}
    })
end
function updateConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local configGui = storage.modSelectGui
    local testModIsRegistered = remote.interfaces["factorio-test-tests-available-for-" .. getTestMod()] ~= nil
    local testModLoaded = remote.interfaces["factorio-test"] ~= nil and remote.call("factorio-test", "modName") == getTestMod()
    local stage = testModLoaded and remote.call("factorio-test", "getTestStage") or nil
    local running = stage == "Running" or stage == "ReloadingMods"
    configGui.modSelect.enabled = not running
    configGui.refreshButton.enabled = not running
    configGui.runButton.enabled = testModIsRegistered and not running
    configGui.runButton.tooltip = testModIsRegistered and "" or ({"factorio-test.config-gui.mod-not-registered"})
end
function createConfigGui(player)
    if game.is_multiplayer() then
        game.print("Cannot run tests in multiplayer")
        return nil
    end
    local ____opt_11 = player.gui.screen[ModSelectGuiName]
    if ____opt_11 ~= nil then
        ____opt_11.destroy()
    end
    storage.modSelectGui = {player = player}
    local frame = player.gui.screen.add({type = "frame", name = ModSelectGuiName, direction = "vertical"})
    frame.auto_center = true
    storage.modSelectGui.mainFrame = frame
    TitleBar(frame, {"factorio-test.config-gui.title"})
    ModSelect(frame)
    TestStageBar(frame)
    updateConfigGui()
    return frame
end
function destroyConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local configGui = storage.modSelectGui
    storage.modSelectGui = nil
    local element = configGui.player.gui.screen[ModSelectGuiName]
    if element and element.valid then
        element.destroy()
    end
end
function refreshConfigGui()
    if not modSelectGuiValid() then
        return
    end
    local previousPlayer = storage.modSelectGui.player
    destroyConfigGui()
    local ____opt_15 = createConfigGui(previousPlayer)
    if ____opt_15 ~= nil then
        ____opt_15.bring_to_front()
    end
end
ModSelectGuiName = "factorio-test:mod-select"
ModSelectWidth = 150
thisModName = script.mod_name
LevelId = "level"
local function setTestMod(mod)
    settings.global["factorio-test-mod-to-test"] = {value = mod}
    updateConfigGui()
end
OnModSelectionChanged = guiAction(
    "OnModSelectionChanged",
    function()
        local ____storage_modSelectGui_6 = storage.modSelectGui
        local modSelect = ____storage_modSelectGui_6.modSelect
        local modSelectValues = ____storage_modSelectGui_6.modSelectValues
        local selectedIndex = modSelect.selected_index
        if selectedIndex == #modSelectValues then
            createModTextField()
        else
            destroyModTextField()
        end
        setTestMod(modSelectValues[selectedIndex] or "")
    end
)
OnModTextfieldChanged = guiAction(
    "OnModTextfieldChanged",
    function(e)
        local element = e.element
        setTestMod(element.text)
    end
)
local refreshAfterLoad = postLoadAction("afterRefresh", refreshConfigGui)
ReloadMods = guiAction(
    "refresh",
    function()
        game.reload_mods()
        refreshAfterLoad()
    end
)
local callRunTests = postLoadAction(
    "runTests",
    function()
        if not startTests() then
            game.print({"factorio-test.config-gui.mod-not-registered"})
            return
        end
        updateConfigGui()
    end
)
RunTests = guiAction(
    "start-tests",
    function()
        game.reload_mods()
        game.auto_save("beforeTest")
        callRunTests()
    end
)
script.on_load(function()
    local ____opt_9 = remote.interfaces["factorio-test"]
    local remoteExits = ____opt_9 and ____opt_9.onTestStageChanged
    if remoteExits then
        local eventId = remote.call("factorio-test", "onTestStageChanged")
        script.on_event(eventId, updateConfigGui)
    end
end)
DestroyConfigGui = guiAction("destroyConfigGui", destroyConfigGui)
local CreateConfigGui = guiAction(
    "createConfigGui",
    function(e)
        if modSelectGuiValid() then
            destroyConfigGui()
        end
        createConfigGui(game.players[e.player_index])
    end
)
local function createModButton(player)
    local flow = modGui.get_button_flow(player)
    local ____opt_13 = flow[ModSelectGuiName]
    if ____opt_13 ~= nil then
        ____opt_13.destroy()
    end
    flow.add({
        type = "sprite-button",
        name = ModSelectGuiName,
        style = modGui.button_style,
        sprite = "factorio-test-test-tube-sprite",
        tooltip = {"factorio-test.tests"},
        tags = {modName = thisModName, on_gui_click = CreateConfigGui}
    })
end
local function createModButtonForAllPlayers()
    for ____, player in pairs(game.players) do
        createModButton(player)
    end
end
script.on_init(createModButtonForAllPlayers)
script.on_configuration_changed(function()
    createModButtonForAllPlayers()
    refreshConfigGui()
end)
script.on_event(
    {defines.events.on_player_created},
    function(e) return createModButton(game.players[e.player_index]) end
)
return ____exports
