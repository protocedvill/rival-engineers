local ____lualib = require("lualib_bundle")
local __TS__SourceMapTraceBack = ____lualib.__TS__SourceMapTraceBack
__TS__SourceMapTraceBack(debug.getinfo(1).short_src, {["5"] = 3,["6"] = 3,["7"] = 4,["8"] = 4,["9"] = 6,["10"] = 6,["11"] = 6,["12"] = 7,["13"] = 8,["15"] = 10,["17"] = 10,["19"] = 6,["20"] = 6,["21"] = 13,["22"] = 13,["23"] = 13,["24"] = 14,["25"] = 15,["27"] = 13,["28"] = 13,["29"] = 19,["30"] = 19,["31"] = 19,["32"] = 20,["33"] = 21,["35"] = 19,["36"] = 19});
local ____exports = {}
local ____util = require("factorio-test.shared.util")
local getPlayer = ____util.getPlayer
local ____guiAction = require("control.guiAction")
local guiAction = ____guiAction.guiAction
guiAction(
    "close-test-gui",
    function()
        if remote.interfaces["factorio-test"] then
            remote.call("factorio-test", "cancelTestRun")
        end
        local ____opt_0 = getPlayer().gui.screen["factorio-test-test-gui"]
        if ____opt_0 ~= nil then
            ____opt_0.destroy()
        end
    end
)
guiAction(
    "cancel-test-run",
    function()
        if remote.interfaces["factorio-test"] then
            remote.call("factorio-test", "cancelTestRun")
        end
    end
)
guiAction(
    "step-action",
    function(e)
        if remote.interfaces["factorio-test"] then
            remote.call("factorio-test", "stepAction", e.element.tags.stepAction)
        end
    end
)
return ____exports
